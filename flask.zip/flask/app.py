from flask import Flask, render_template,request,flash
import os
import psycopg2
import json
import sqlite3
from pyproj import Proj
from pyproj import Transformer
import sqlite3
conn = psycopg2.connect(
        host="192.168.1.213",
        database="SAMA1107",
        user="postgres",
        password="postgres",
        port=5432)

if conn:
    print('database connected')
else:
    print('databse not connected')


app = Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

@app.route('/index', methods=['GET','POST'])
def sr_data():
    cursor = conn.cursor()
    arr=0

    if request.method == "POST":
        east=request.form.get("easting")
        north=request.form.get("northing")
        range=request.form.get("range")
        azimuth=request.form.get("az")
        tr_type=request.form.get("target_type")
        date=request.form.get("date")
        time=request.form.get("time")
        speed=request.form.get("speed")
        heading=request.form.get("heading")
        strength=request.form.get("strength")
        desc=request.form.get("description")
        
        print(east,north,range,tr_type,azimuth,desc,speed,heading,strength,date,time)
        from_module = "PC"
        sensor = 'Radar'
        sensor_id = "SR_100"
        sensor_type ='BFSR 2140' 
        fmn_code = "7010030003"
        sus_no = "7013301U"
        level_in_hierarchy= "Unit"
        status = 'P'

        transfrom = Transformer.from_crs(24379, 4326)
        point_43279 = [(float(east), float(north))]
        point_4326 = transfrom.itransform(point_43279)
        my_string = str(*point_4326)
        coord = "POINT " + my_string.replace(',', '')
        coord_str = my_string[1:-1]
        lon, lat = float(coord_str.split(',')[0]), float(coord_str.split(',')[1])        
        try:
            q = "insert into enemy_activity1(speed,heading,strength,description,target_type,status,sensor_id,level_in_hierarchy,susno,fmn_code,sensor,sensor_type,tdate,ttime,from_module,lon,lat,azimuth,range,geom) values ('"+speed+"','"+heading+"','"+strength+"','"+desc+"','"+tr_type+"','"+status+"','"+sensor_id+"','"+level_in_hierarchy+"','"+sus_no+"','"+fmn_code+"','"+sensor+"','"+sensor_type+"','"+date+"','"+time+"','"+from_module+ "','" + str(lat) + "', '" + str(lon) + "','" + azimuth + "','" + range + "',st_point(" + str(lat) + "," + str(lon) + "))"
            cursor.execute(q)
            conn.commit()
            print('saved')

        except:
            pass

    
    return render_template('index.html',arr=arr)


@app.route('/fetch_Data')
def fetch_data():
    arr = 0
    dict = {'target_p':''}

    connection = sqlite3.connect("/home/bisag/Music/bfsr_chiloda/BFSR_PRED1.db")

    cursor = connection.cursor()


    sel = "select target_name from pred order by id desc"
    cursor.execute(sel)
    result = cursor.fetchone()
    target = result[0]
    dict['target_p'] = target

    file = '/home/bisag/xavier_apps/BFSR_GUI_SR/geojsonurl/Targat_location_EN.json'
    if os.stat(file).st_size==0:
        try:
            print('file is empty','------------------')
            flash('File is empty cannot find data  ')
        except:
            pass 
    else:
        try:
            with open(file,'r') as f:
                data = f.read()
                arr = json.loads(data)
                arr.update(dict)
                print(arr)
                flash('Data fetched successfully')
        except:
            pass
    return render_template('index.html',arr=arr)


@app.route('/hhti_fetch_Data')
def hhti_fetch_data():
    arr = 0

    connection = sqlite3.connect('/home/bisag/webapp/HHTIBASE.db')

    cursor = connection.cursor()    


    cursor.execute('select target_p from HHTI order by id desc')

    result = cursor.fetchone()
    # print(result)
    dic_new = {'target_p':''}
    for i in result:
        dic_new['target_p'] = i
    print(dic_new)
    file = '/home/bisag/xavier_apps/HHTI_GUI_RJ/geojsonurl/HHTI_Targat_location.json'
    if os.stat(file).st_size==0:
        try:
            print('file is empty','------------------')
            flash('File is empty cannot find data  ')
        except:
            pass 
    else:
        try:
            with open(file,'r') as f:
                data = f.read()
                arr = json.loads(data)
                arr.update(dic_new)
                print(arr)
                flash('Data fetched successfully')
        except:
            pass
    return render_template('hhti.html',arr=arr)

@app.route('/hhti', methods=['GET','POST'])
def hhti_data():
    arr=0
    cursor = conn.cursor() 
    if request.method == "POST":

        east=request.form.get("easting")
        north=request.form.get("northing")
        range=request.form.get("range")
        azimuth=request.form.get("azimuth")
        tr_type=request.form.get("target_type")
        lat=request.form.get("lat")
        lon=request.form.get("lon")
        strength=request.form.get("strength")
        desc=request.form.get("description")
        date = request.form.get("date")
        time = request.form.get("time")
        sensor = 'Electro Optical'
        sensor_type ='HHTI' 
        sensor_id = "TI_123" 
        fmn_code = "7010030003"
        sus_no = "7013301U"
        level_in_hierarchy= "Unit"
        from_module = "PC"
        status = "P"
        print(east,north,range,tr_type,azimuth,lat,lon)
        flash('Data saved successfully')
   
        try:
   
            q = "insert into enemy_activity1(strength,description,target_type,status,sensor_id,level_in_hierarchy,susno,fmn_code,sensor,sensor_type,tdate,ttime,from_module,lon,lat,azimuth,range,geom) values ('"+strength+"','"+desc+"','"+tr_type+"','"+status+"','"+sensor_id+"','"+level_in_hierarchy+"','"+sus_no+"','"+fmn_code+"','"+sensor+"','"+sensor_type+"','"+date+"','"+time+"','"+from_module+ "','" + str(lat) + "', '" + str(lon) + "','" + azimuth + "','" + range + "',st_point(" + str(lat) + "," + str(lon) + "))"

            cursor.execute(q)
            conn.commit()
            print('saved')
        except:
            pass
    return render_template('hhti.html',arr=arr)



if __name__ == '__main__':
    app.run(debug=True,port=5001)


