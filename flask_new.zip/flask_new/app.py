import re
from flask import Flask, render_template,request,flash
import os
import psycopg2
import json
import sqlite3


conn = psycopg2.connect(
        host="localhost",
        database="flask_db",
        user="postgres",
        password="ronit")

# if conn:
#     print('database connected')
# else:
#     print('databse not connected')


app = Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

@app.route('/index', methods=['GET','POST'])
def sr_data():
    arr=0

    if request.method == "POST":
        #Create an empty list
     
        #Create a munro dictionary
        east=request.form.get("east")
        north=request.form.get("north")
        range=request.form.get("range")
        target=request.form.get("target")
        azimuth=request.form.get("az")
     
        print(east,north,range,target,azimuth)
        cursor = conn.cursor()
        command = "insert into prac(name) values('"+str(east)+"')"
        cursor.execute(command)
        conn.commit()
        flash('Data saved successfully')
        sel = "select name from prac"
        cursor.execute(sel)
        result = cursor.fetchall()
        print(result)
    return render_template('index.html',arr=arr)




@app.route('/fetch_Data')
def fetch_data():
    arr = 0
    dict = {'target':''}

    connection = sqlite3.connect("test.db")

    cursor = connection.cursor()


    sel = "select name from data_test order by id desc"
    cursor.execute(sel)
    result = cursor.fetchone()
    target = result[0]
    dict['target'] = target

    file = '/home/ronit/Downloads/flask_app/file.json'
    if os.stat(file).st_size==0:
        try:
            print('file is empty','------------------')
            flash('File is empty cannot find data  ')
        except:
            pass 
    else:
        try:
            with open(file,'r') as f:
                data = f.read()
                arr = json.loads(data)
                arr.update(dict)
                print(arr)
                flash('Data fetched successfully')
        except:
            pass
    return render_template('index.html',arr=arr)


@app.route('/hhti_fetch_Data')
def hhti_fetch_data():
    arr = 0
    dict = {'target':''}

    connection = sqlite3.connect("test.db")

    cursor = connection.cursor()


    sel = "select name from data_test order by id desc"
    cursor.execute(sel)
    result = cursor.fetchone()
    target = result[0]
    dict['target'] = target

    file = '/home/ronit/Downloads/flask_app/file.json'
    if os.stat(file).st_size==0:
        try:
            print('file is empty','------------------')
            flash('File is empty cannot find data  ')
        except:
            pass 
    else:
        try:
            with open(file,'r') as f:
                data = f.read()
                arr = json.loads(data)
                arr.update(dict)
                print(arr)
                flash('Data fetched successfully')
        except:
            pass
    return render_template('index.html',arr=arr)

@app.route('/hhti', methods=['GET','POST'])
def hhti_data():
    arr=0

    if request.method == "POST":
        #Create an empty list
     
        #Create a munro dictionary
        east=request.form.get("east")
        north=request.form.get("north")
        range=request.form.get("range")
        target=request.form.get("target")
        azimuth=request.form.get("az")
     
        print(east,north,range,target,azimuth)
        cursor = conn.cursor()
        command = "insert into prac(name) values('"+str(east)+"')"
        cursor.execute(command)
        conn.commit()
        flash('Data saved successfully')
        sel = "select name from prac"
        cursor.execute(sel)
        result = cursor.fetchall()
        print(result)
    return render_template('hhti.html',arr=arr)

@app.route('/hhti')
def index():
    return render_template('hhti.html')


if __name__ == '__main__':
    app.run(debug=True,port=5002)


  


