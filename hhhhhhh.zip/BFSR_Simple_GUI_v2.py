# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'BFSR_Simple_GUI_v2.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!
from email.mime import audio
import os, sys,time,cv2,easyocr
import threading
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtCore import QThread, pyqtSignal, pyqtSlot
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtWidgets import QWidget
from pyproj import Transformer
from helpers import get_bfsr_location, get_target_location, clear_target_locations
import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets
import pyqtgraph
import SWHear
import warnings
import faulthandler
import sqlite3
import pyaudio
import pyqtgraph
from collections import Counter
import torch
from matplotlib import pyplot as plt
from training.model import AudioCNNClassifier, infer
from torchvision.transforms import Normalize
from qtpy import QtCore, QtGui, QtWidgets

import wave
import matplotlib.pyplot as plt

device = 'cpu'
desired_sr = 16000
max_audio_duration_ms = 5000

checkpoint = torch.load("training/models/bfsr_cnn_librosa_dharanghdhara_lt_hv.pt", map_location=device)
#checkpoint = torch.load("training/models/bfsr_cnn_librosa_chiloda_v3.pt", map_location=device)
cnn = AudioCNNClassifier()
cnn.load_state_dict(checkpoint["model_state_dict"])

prediction_history = ['','','','','']
            
prediction_print = ''                         

swap_wav = 'audacity'

faulthandler.enable()

warnings.filterwarnings("ignore")

class MicThread(QtCore.QThread):
    sig = QtCore.Signal(bytes)
    def __init__(self, sc):
        super(MicThread, self).__init__()
        self.sc = sc
        self.sig.connect(self.sc.append)
        self.running = True

    def run(self):
        global prediction_print
        self.updatesPerSecond = 5
        self.chunksRead = 0
        self.device = device
        self.rate = 44100
        self.chunk = self.rate  # gets replaced automatically
        self.buffer = None
        self.inference_window_size_secs = 5 # Change depending on the model
        self.preds = []
        self.probs = []
        self.keep_preds_size = (12 * self.rate) / self.chunk
        self.final_prediction = ''
        #class_to_idx = {"heavy vehicle": 0, "light vehicle": 1}
        #class_to_idx = {"Heavy Vehicle": 0, "crawling man": 1, "group of men": 2, "single walking man": 3}
        #class_to_idx = {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1, "GROUP OF MEN": 2}
        class_to_idx = {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1}
        #class_to_idx = {"VEHICLE": 0, "GROUP OF MEN": 1}
        self.idx_to_class = {v: k for k, v in class_to_idx.items()}
        self.frames = []
        try:
            while self.running:
                self.keepRecording = True  # set this to False later to terminate stream
                self.dataa = None  # will fill up with threaded recording data
                self.fft = None
                self.dataFiltered = None 
                readdata = self.sc.stream.read(self.sc.CHUNK)
                self.sig.emit(readdata)
                self.dataa = np.frombuffer(readdata, dtype=np.int16).astype(np.float32, order='C') / 32768.0
                self.frames.append(readdata)
                if self.buffer is not None:
                    self.buffer = np.hstack([self.buffer, self.dataa])
                else:
                    self.buffer = self.dataa
                if self.buffer.shape[0] > (self.rate * self.inference_window_size_secs):
                    self.buffer = self.buffer[-(self.rate * self.inference_window_size_secs):]
                # plt.hist(self.data, bins=1000)
                # plt.show()
                nb_recent_samples = int(1 * self.rate)
                # if (np.logical_and(-.003 <= self.buffer[-nb_recent_samples:],
                #                    self.buffer[-nb_recent_samples:] <= .003).sum() / self.buffer[-nb_recent_samples:].shape[
                #         0]) > .8:
                if np.max(self.buffer[-nb_recent_samples:]) - np.min(self.buffer[-nb_recent_samples:]) <= 0.002:
                    self.final_prediction = 'No sound or Noise'
                    self.preds.clear()
                    self.probs.clear()
                    prediction_print = self.final_prediction
                    prediction_history.append(prediction_print)
                    if len(prediction_history) == 6:
                        prediction_history.pop(0)
                        
                    
                       
                    # prediction_history[-5:]
                    
                # TODO: detect noise function
                else:
                    if self.buffer.shape[0] == (self.rate * self.inference_window_size_secs):
                        # input_tensor = torch.from_numpy(self.buffer).unsqueeze(0).type(torch.float32)
                        input_audio = np.copy(self.buffer)
                        prob, pred_id = infer(classifier=cnn,
                                            data=input_audio,
                                            input_sr=self.rate,
                                            desired_sr=desired_sr,
                                            max_audio_duration_ms=max_audio_duration_ms,
                                            normalize=Normalize(mean=[51.55220031738281], std=[20.79323387145996]))
                        if len(self.preds) == self.keep_preds_size:
                            del self.preds[0]
                            del self.probs[0]

                        # print(self.preds)
                        self.preds.append(pred_id)
                        self.probs.append(prob)

                        frqs = Counter(self.preds)
                        final_pred_id = frqs.most_common(1)[0][0]
                        cnt = 0
                        avg = 0
                        for i, prob in enumerate(self.probs):
                            if self.preds[i] == final_pred_id:
                                avg += self.probs[i]
                                cnt += 1
                        avg_prob = (avg / cnt) * 100
                        self.final_prediction = f"{self.idx_to_class[pred_id]} : {int(prob*100)}%"
                        prediction_print = self.final_prediction
                        prediction_history.append(prediction_print)
                        if len(prediction_history) == 6:
                            prediction_history.pop(0)
                       
                        self.buffer = None

        except:
            (type, value, traceback) = sys.exc_info()
            sys.stdout.write(str(type))
            sys.stdout.write(str(value))
            sys.stdout.write(str(traceback.format_exc()))
            
    # def stop(self):
    #     sys.stdout.write('THREAD STOPPED')
    #     self.running = False

class StreamController(QtGui.QMainWindow):
    def __init__(self):
        super(StreamController, self).__init__()
        self.data = np.zeros((555555), dtype=np.int32)
        self.CHUNK = 1024
        # self.CHANNELS = 1
        self.RATE = 44100
        # self.FORMAT = pyaudio.paInt16
        
    def setup_stream(self):
        self.audio = pyaudio.PyAudio()
        
        
        # self.stream = self.earac.stream_startac(self)
        self.stream = self.audio.open(format=pyaudio.paInt16,  channels=1, rate=self.RATE, 
                            input=True, frames_per_buffer=self.CHUNK)
        self.micthread = MicThread(self)
        self.micthread.start()
        

    def append(self, vals):
        vals = np.frombuffer(vals, 'int16')
        c = self.CHUNK
        self.data[:-c] = self.data[c:]
        self.data[-c:] = vals
        
    # def breakdown_stream(self):
    #     self.micthread.terminate()
    #     self.stream.stop_stream()
    #     self.stream.close()
    #     self.audio.terminate()
    #     loop = QtCore.QEventLoop()
    #     QtCore.QTimer.singleShot(400, loop.quit)
    #     loop.exec_()
class Thread(QThread):
    sig = QtCore.Signal(bytes)
    changePixmap = pyqtSignal(QImage)

    def __init__(self, width, height):
        super().__init__()
        self.width, self.height = width, height

    def run(self):
        # self._stop_event = threading.Event()
        global kill_set_img_th
        # cap = cv2.VideoCapture(0)
        cap = cv2.VideoCapture('cdu_screen_video.mp4')
        while not kill_set_img_th:
            ret, frame = cap.read()
            if ret:
                # https://stackoverflow.com/a/55468544/6622587
                global current_frame
                current_frame = np.copy(frame)
                current_frame = cv2.resize(current_frame, (640, 480))
                img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                h, w, ch = img.shape
                bytes_per_line = ch * w
                qt_img = QImage(img.data, w, h, bytes_per_line, QImage.Format_RGB888)
                p = qt_img.scaled(self.width, self.height, QtCore.Qt.IgnoreAspectRatio)
                self.changePixmap.emit(p)
                time.sleep(1 / 30)
            else:
                break
        cap.release()

    # def stop(self):
    #     self._stop_event.set()

'''
def capture_target_location(_easyocr, transformer):
    # For image of size 640x480
    global kill_ocr_thread
    roi_box_coords = [[440, 155], [635, 475]]  # Top left, Bottom right (x, y)
    while not kill_ocr_thread:
        if ocr_on_target_screen_flag:
            roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
            get_target_location(roi, _easyocr, transformer)
            # time.sleep(15)

'''
    # self.grFFT.plotItem.showGrid(True, True, 0.7)
    #     self.grPCM.plotItem.showGrid(True, True, 0.7)
grFFT = 0
grPCM = 0
var = ""
# conn = sqlite3.connect('BFSR_PRED.db')
class Ui_MainWindow(QWidget):
    # read_collected = QtCore.pyqtSignal(np.ndarray)
    def __init__(self):
        super(Ui_MainWindow,self).__init__()

    def setupUi(self, MainWindow):
        global grFFT
        global grPCM
        MainWindow.setObjectName("MainWindow")

        screen_size = app.primaryScreen().size()
        self.window_width = screen_size.width() - 100
        self.window_height = screen_size.height() - 100

        MainWindow.setFixedSize(self.window_width, self.window_height)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.keyPressEvent = self.keyPressEvent
        self.centralwidget.setObjectName("centralwidget")
        self.capture_bfsr_location_button = QtWidgets.QPushButton(self.centralwidget)
        self.capture_bfsr_location_button.setGeometry(QtCore.QRect(10, 20, 201, 25))
        self.capture_bfsr_location_button.setObjectName("pushButton")
        self.target_capture_button = QtWidgets.QPushButton(self.centralwidget)
        self.target_capture_button.setGeometry(QtCore.QRect(210, 20, 141, 25))
        self.target_capture_button.setObjectName("pushButton_2")
        self.cdu_screen_label = QtWidgets.QLabel(self.centralwidget)
        self.target_type = ""

        vid_width = self.window_width - 20
        vid_height = self.window_height - 80
        self.cdu_screen_label.setGeometry(QtCore.QRect(10, 60,
                                                       vid_width,
                                                       vid_height))
        self.cdu_screen_label.setObjectName("graphicsView")
        self.clear_targets_button = QtWidgets.QPushButton(self.centralwidget)
        self.clear_targets_button.setGeometry(QtCore.QRect(350, 20, 141, 25))
        self.clear_targets_button.setObjectName("pushButton_3")
        self.show_on_map_button = QtWidgets.QPushButton(self.centralwidget)
        self.show_on_map_button.setGeometry(QtCore.QRect(490, 20, 141, 25))
        self.show_on_map_button.setObjectName("pushButton_4")
        self.label1 = QtWidgets.QLabel(self.centralwidget)

        # vid_width = self.window_width - 20
        # vid_height = self.window_height - 80
        self.label1.setGeometry(QtCore.QRect(920, 60, 880, 920))
        self.label1.setStyleSheet("border: 1px solid black;")
        self.label1.setObjectName("graphicsView")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        
        #**********************#
        
        # self.centralwidget = QtWidgets.QWidget(MainWindow)
        # self.centralwidget.setObjectName("centralwidget")
        
        
        self.swap_to_spr = QtWidgets.QPushButton(self.centralwidget)
        self.swap_to_spr.setGeometry(QtCore.QRect(1300, 20, 180, 25))
        self.swap_to_spr.setObjectName("swap_to_sprectogram")
        
        
        pyqtgraph.setConfigOption('background', 'w') 
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.label1)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.pbLevel = QtWidgets.QProgressBar(self.label1)
        self.pbLevel.setMaximum(1000)
        self.pbLevel.setProperty("value", 123)
        self.pbLevel.setTextVisible(False)
        self.pbLevel.setOrientation(QtCore.Qt.Vertical)
        self.pbLevel.setObjectName("pbLevel")
        self.horizontalLayout.addWidget(self.pbLevel)
        self.frame = QtWidgets.QFrame(self.label1)
        self.frame.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.frame.setFrameShadow(QtWidgets.QFrame.Plain)
        self.frame.setObjectName("frame")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.frame)
        self.verticalLayout.setContentsMargins(0, 0, 0, 50)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_3 = QtWidgets.QLabel(self.frame)
        self.label_3.setObjectName("label_3")
        self.label_3.setGeometry(0,0, 880,22)
        
        # self.verticalLayout.addWidget(self.label_3)
        self.grPCMnew = PlotWidget(self.frame)
        self.grPCMnew.setObjectName("grPCMnew")
        # self.verticalLayout.addWidget(self.grPCMnew)
        self.grPCMnew.setGeometry(0,24, 438, 274)
        
        
        self.label_h = QtWidgets.QLabel(self.frame)
        self.label_h.setObjectName("label_3")
        self.label_h.setGeometry(440,24, 430,274)
        
        
        self.label_hh = QtWidgets.QLabel(self.label_h)
        # self.verticalLayout.addWidget(self.label_h1)
        self.label_hh.setText('History')
        self.label_hh.setGeometry(0,0, 430,25)
        
        self.label_h1 = QtWidgets.QLabel(self.label_h)
        # self.verticalLayout.addWidget(self.label_h1)
        self.label_h1.setGeometry(0,25, 430,50)
        
        self.label_h2 = QtWidgets.QLabel(self.label_h)
        # self.verticalLayout.addWidget(self.label_h2)    
        self.label_h2.setGeometry(0,75, 430,50)

        
        self.label_h3 = QtWidgets.QLabel(self.label_h)
        # self.verticalLayout.addWidget(self.label_h3)    
        self.label_h3.setGeometry(0,125, 430,50)

        
        self.label_h4 = QtWidgets.QLabel(self.label_h)
        # self.verticalLayout.addWidget(self.label_h4)   
        self.label_h4.setGeometry(0,175, 430,50)

        
        self.label_h5 = QtWidgets.QLabel(self.label_h)
        # self.verticalLayout.addWidget(self.label_h5)      
        self.label_h5.setGeometry(0,225, 430,50)

        
        
        
        font = QtGui.QFont()
        self.prediction = QtWidgets.QLabel(self.frame)
        self.prediction.setGeometry(0,300,880, 50)
        
        font.setPointSize(20)
        self.prediction.setFont(font)
        self.prediction.setObjectName("prediction")
        
        # self.verticalLayout.addWidget(self.prediction,0, QtCore.Qt.AlignHCenter)
        
        
        # self.label_rh = QtWidgets.QLabel(self.frame)
        # self.label_rh.setObjectName("label")
        # self.label_rh.setGeometry(0,352,880, 24)
        
        #class_to_idx = {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1, "GROUP OF MEN": 2}
        
        self.label_rhlv = QtWidgets.QLabel(self.frame)
        self.label_rhlv.setText("LIGHT VEHICLE")
        self.label_rhlv.setGeometry(0,352,285, 24)
        self.label_rhhv= QtWidgets.QLabel(self.frame)
        self.label_rhhv.setText("HEAVY VEHICLE")
        self.label_rhhv.setGeometry(285,352,285, 24)
        self.label_rhgm = QtWidgets.QLabel(self.frame)
        self.label_rhgm.setText("GROUP OF MEN")
        self.label_rhgm.setGeometry(570,352,285, 24)
        
        
        
        self.label_r = QtWidgets.QLabel(self.frame)
        self.label_r.setObjectName("label")
        self.label_r.setGeometry(0,378,880, 177)
        
        
        self.label_rhlv = QtWidgets.QLabel(self.frame)
        self.label_rhlv.setGeometry(0,378,285, 177)
        self.label_rhlv.setPixmap(QPixmap('my_plot.png'))
        self.label_rhlv.setScaledContents(True)
        self.label_rhhv= QtWidgets.QLabel(self.frame)
        self.label_rhhv.setGeometry(285,378,285, 177)
        self.label_rhhv.setPixmap(QPixmap('my_plot.png'))
        self.label_rhhv.setScaledContents(True)
        self.label_rhgm = QtWidgets.QLabel(self.frame)
        self.label_rhgm.setGeometry(570,378,285, 177)
        self.label_rhgm.setPixmap(QPixmap('my_plot.png'))
        self.label_rhgm.setScaledContents(True)
        
        self.label = QtWidgets.QLabel(self.frame)
        self.label.setObjectName("label")
        self.label.setGeometry(0,557,880, 24)
        
        # self.verticalLayout.addWidget(self.label)
        # self.grFFT = PlotWidget(self.frame)
        # self.grFFT.setObjectName("grFFT")
        # self.verticalLayout.addWidget(self.grFFT)
        
        self.label_2 = QtWidgets.QLabel(self.frame)
        self.label_2.setObjectName("label_2")
        self.label_2.setGeometry(0,583,880, 300)
        self.label_2.setPixmap(QPixmap('dg.png'))
        self.label_2.setScaledContents(True)
        
        
        # self.verticalLayout.addWidget(self.label_2)
        
        
        # self.grPCM = PlotWidget(self.frame)
        # self.grPCM.setObjectName("grPCM")
        # self.grPCMa.setGeometry(0,378,880, 500)
        # self.verticalLayout.addWidget(self.grPCMa)
        self.horizontalLayout.addWidget(self.frame)
        MainWindow.setCentralWidget(self.centralwidget)
        
        pyqtgraph.setConfigOption('background', 'w')
        
        self.data = np.zeros((555555), dtype=np.int32)
        self.CHUNK = 1024
        # self.CHANNELS = 1
        self.RATE = 44100
        
        # self.grFFT.plotItem.showGrid(True, True, 0.7)
        # self.grPCM.plotItem.showGrid(True, True, 0.7)
        self.grPCMnew.plotItem.showGrid(True, True, 0.5)
        self.maxFFT = 0
        self.maxPCM = 0
        prediction_print = ''
        self.sc = StreamController()
        self.sc.setup_stream()

        #**********************#
        

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.capture_bfsr_location_button.clicked.connect(self.capture_bfsr_location_button_listener)
        self.target_capture_button.clicked.connect(self.target_capture_button_listener)
        self.clear_targets_button.clicked.connect(self.clear_targets_button_listener)

        
        self.swap_to_spr.clicked.connect(self.swap_to_sprectogram)

        
        self._easyocr = easyocr.Reader(["en"])
        self.transformer = Transformer.from_crs(24379, 4326)

        self.video_display_th = Thread(880, 920)
        self.video_display_th.changePixmap.connect(self.set_image)
        self.video_display_th.setTerminationEnabled(True)
        self.video_display_th.start()
        
        # self.ear = SWHear.SWHear.stream_readchunk(self)
        # self.ear.stream_start()
    def swap_to_sprectogram(self):
        global swap_wav
        if swap_wav == 'audacity':
            self.label_rhlv.setPixmap(QPixmap('11.jpeg'))
            self.label_rhhv.setPixmap(QPixmap('11.jpeg'))
            self.label_rhgm.setPixmap(QPixmap('11.jpeg'))
            self.swap_to_spr.setText("swap_to_audacity")
            swap_wav = 'sprectogram'
        else:
            self.label_rhlv.setPixmap(QPixmap('my_plot.png'))
            self.label_rhhv.setPixmap(QPixmap('my_plot.png'))
            self.label_rhgm.setPixmap(QPixmap('my_plot.png'))
            self.swap_to_spr.setText("swap_to_sprectogram")
            swap_wav = 'audacity'
            
            

        
    def update_streamplot(self):
        self.pdataitem.setData(self.sc.data)
    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.capture_bfsr_location_button.setText(_translate("MainWindow", "Cap BFSR Loc"))
        self.target_capture_button.setText(_translate("MainWindow", "Cap Tgt Loc"))
        self.clear_targets_button.setText(_translate("MainWindow", "Clear Tgts"))
        self.show_on_map_button.setText(_translate("MainWindow", "Show Map"))
        self.label.setText(_translate("MainWindow", "Spectrogram : "))
        self.label_3.setText(_translate("MainWindow", "Audacity Wav : "))
        self.prediction.setText(_translate("MainWindow", "<>"))
        self.swap_to_spr.setText(_translate("MainWindow", "swap_to_sprectogram"))
        
        
        # self.label_2.setText(_translate("MainWindow", "Raw Data (PCM):"))
        


    def update(self):
        from BFSR_Simple_GUI_v2 import MicThread
        # if not earac.data is None and not earac.fft is None:
                # self.grPCM.plotItem.setRange(yRange=[-pcmMax, pcmMax])
            # if np.max(earac.fft) > self.maxFFT:
            #     self.maxFFT = np.max(np.abs(earac.fft))
                # self.grFFT.plotItem.setRange(yRange=[0,self.maxFFT])
                # self.grFFT.plotItem.setRange(yRange=[0, 1])
                
        pcmMax = np.max(np.abs(self.sc.data))
        if pcmMax > self.maxPCM:
            self.maxPCM = pcmMax
        try:
            self.pbLevel.setValue(1000 * pcmMax / self.maxPCM)
            pass
        except TypeError:
            self.pbLevel.setValue(0)
        # print('===============>>>>>>>>>>'+str(prediction_history))
        
        self.label_h1.setText(prediction_history[4])
        self.label_h2.setText(prediction_history[3])
        self.label_h3.setText(prediction_history[2])
        self.label_h4.setText(prediction_history[1])
        self.label_h5.setText(prediction_history[0])
        
        
        # self.label_h1.setText('')
        # self.label_h2.setText('')
        # self.label_h3.setText('')
        # self.label_h4.setText('')
        # self.label_h5.setText('')

        
        self.prediction.setText(prediction_print)
        # pen = pyqtgraph.mkPen(color='b')
        # self.grPCMa.plot(self.win, pen=pen, clear=True)
        # pen = pyqtgraph.mkPen(color='r')
        # self.grFFT.plot(self.ear.fftx, self.ear.fft / self.maxFFT, pen=pen, clear=True)
        pen = pyqtgraph.mkPen(color='b')         
        self.grPCMnew.plotItem.setRange(yRange=[-30000, 30000])
        self.grPCMnew.plot(self.sc.data, pen=pen, clear=True)
        # global var
        # var = self.ear.final_prediction[0:14]
        # with open('file_audio.txt','w') as f:
        #     f.write(str(var))
                
      

        QtCore.QTimer.singleShot(1, self.update)  # QUICKLY
    
    # def update_sprc(self, chunk):
    #     # normalized, windowed frequencies in data chunk
    #     spec = np.fft.rfft(chunk*self.win) / CHUNKSZ
    #     # get magnitude 
    #     psd = abs(spec)
    #     # convert to dB scale
    #     psd = 20 * np.log10(psd)

    #     # roll down one and replace leading edge with new data
    #     self.img_array = np.roll(self.img_array, -1, 0)
    #     self.img_array[-1:] = psd

    #     self.img.setImage(self.img_array, autoLevels=False)
    
        
    def capture_bfsr_location_button_listener(self):
        print("capture_bfsr_location_button function called")
        global current_frame
        # cv2.imwrite('logs/bfsr_location.png',current_frame)
        # For image of size 640x480
        roi_box_coords = [[260, 290], [400, 340]]  # Top left, Bottom right (x, y)
        roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
        ret = get_bfsr_location(roi, self._easyocr, self.transformer)
        

    def target_capture_button_listener(self):
        print("target_capture_button function called")
        # cv2.imwrite('logs/target_location.png',current_frame)
        
        roi_box_coords = [[440, 155], [635, 475]]  # Top left, Bottom right (x, y)
        roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
        ret = get_target_location(roi,self.target_type, self._easyocr, self.transformer) 

    def clear_targets_button_listener(self):
        print("clear_targets_button function called")
        clear_target_locations()
        

    @pyqtSlot(QImage)
    def set_image(self, image):
        
        self.cdu_screen_label.setPixmap(QPixmap.fromImage(image))
        
    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_1:
            self.target_type = "No sound"
        elif event.key() == QtCore.Qt.Key_2:
            self.target_type = "Heavy vehicle"
        elif event.key() == QtCore.Qt.Key_3:
            self.target_type = "Light vehicle"
        elif event.key() == QtCore.Qt.Key_4:
            self.target_type = "Group of men"
        print(self.target_type)
        
# cursor = conn.cursor()
# command = "CREATE TABLE IF NOT EXISTS PRED(id AUTO INCREMENT PRIMARY KEY,target_name Varchar)"
# cursor.execute(command)
# comm ="INSERT INTO pred (target_name) VALUES ('"+str(var)+"')"
# cursor.execute(comm)
# cursor.close()
# conn.commit()
from pyqtgraph import PlotWidget


if __name__ == "__main__":
    
    # sys.stdout = open('stdout.txt', 'w')
    # sys.stderr = open('stderr.txt', 'w')

    os.environ["CUDA_VISIBLE_DEVICES"] = "0"

    kill_set_img_th = False
    current_frame = True

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    
    ui.update()
    
    MainWindow.show()
    # ui.read_collected.connect(ui.update_sprc)

    # mic = MicrophoneRecorder(ui.read_collected)

    # # time (seconds) between reads
    # interval = FS/CHUNKSZ
    # t = QtCore.QTimer()
    # t.timeout.connect(mic.read)
    # t.start(1000/interval) #QTimer takes ms
    
    
    exit_status = app.exec_()
    kill_set_img_th = True
    sys.exit(exit_status)
