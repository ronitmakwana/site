import numpy as np
import sys, os
import pyaudio
import wave
import pyqtgraph
from qtpy import QtCore, QtGui, QtWidgets
import matplotlib.pyplot as plt


"""
this is a stripped down version of the SWHear class.
It's designed to hold only a single audio sample in memory.
check my githib for a more complete version:
    http://github.com/swharden
"""
from collections import Counter
import time
import threading
import torch
from matplotlib import pyplot as plt
from training.model import AudioCNNClassifier, infer
from torchvision.transforms import Normalize
from qtpy import QtCore, QtGui, QtWidgets


device = 'cpu'
desired_sr = 16000
max_audio_duration_ms = 5000

checkpoint = torch.load("training/models/bfsr_cnn_librosa_dharanghdhara_lt_hv.pt", map_location=device)
#checkpoint = torch.load("training/models/bfsr_cnn_librosa_chiloda_v3.pt", map_location=device)
cnn = AudioCNNClassifier()
cnn.load_state_dict(checkpoint["model_state_dict"])




def getFFT(data, rate):
    """Given some data and rate, returns FFTfreq and FFT (half)."""
    data = data * np.hamming(len(data))
    fft = np.fft.fft(data)
    fft = np.abs(fft)
    # fft=10*np.log10(fft)
    freq = np.fft.fftfreq(len(fft), 1.0 / rate)
    return freq[:int(len(freq) / 2)], fft[:int(len(fft) / 2)]

class MicThread(QtCore.QThread):
    sig = QtCore.Signal(bytes)
    def __init__(self, sc):
        super(MicThread, self).__init__()
        self.sc = sc
        self.sig.connect(self.sc.append)
        self.running = True

    def run(self):
        self.updatesPerSecond = 5
        self.chunksRead = 0
        self.device = device
        self.rate = 44100
        self.chunk = self.rate  # gets replaced automatically
        self.buffer = None
        self.inference_window_size_secs = 5 # Change depending on the model
        self.preds = []
        self.probs = []
        self.keep_preds_size = (12 * self.rate) / self.chunk
        self.final_prediction = ''
        #class_to_idx = {"heavy vehicle": 0, "light vehicle": 1}
        #class_to_idx = {"Heavy Vehicle": 0, "crawling man": 1, "group of men": 2, "single walking man": 3}
        #class_to_idx = {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1, "GROUP OF MEN": 2}
        class_to_idx = {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1}
        #class_to_idx = {"VEHICLE": 0, "GROUP OF MEN": 1}
        self.idx_to_class = {v: k for k, v in class_to_idx.items()}
        self.frames = []
        try:
            while self.running:
                self.keepRecording = True  # set this to False later to terminate stream
                self.dataa = None  # will fill up with threaded recording data
                self.fft = None
                self.dataFiltered = None 
                readdata = self.sc.stream.read(self.sc.CHUNK)
                self.sig.emit(readdata)
                self.dataa = np.frombuffer(readdata, dtype=np.int16).astype(np.float32, order='C') / 32768.0
                self.frames.append(readdata)
                if self.buffer is not None:
                    self.buffer = np.hstack([self.buffer, self.dataa])
                else:
                    self.buffer = self.dataa
                if self.buffer.shape[0] > (self.rate * self.inference_window_size_secs):
                    self.buffer = self.buffer[-(self.rate * self.inference_window_size_secs):]
                # plt.hist(self.data, bins=1000)
                # plt.show()
                nb_recent_samples = int(1 * self.rate)
                # if (np.logical_and(-.003 <= self.buffer[-nb_recent_samples:],
                #                    self.buffer[-nb_recent_samples:] <= .003).sum() / self.buffer[-nb_recent_samples:].shape[
                #         0]) > .8:
                if np.max(self.buffer[-nb_recent_samples:]) - np.min(self.buffer[-nb_recent_samples:]) <= 0.002:
                    self.final_prediction = 'No sound or Noise'
                    self.preds.clear()
                    self.probs.clear()
                    print(self.final_prediction)
                # TODO: detect noise function
                else:
                    if self.buffer.shape[0] == (self.rate * self.inference_window_size_secs):
                        # input_tensor = torch.from_numpy(self.buffer).unsqueeze(0).type(torch.float32)
                        input_audio = np.copy(self.buffer)
                        prob, pred_id = infer(classifier=cnn,
                                            data=input_audio,
                                            input_sr=self.rate,
                                            desired_sr=desired_sr,
                                            max_audio_duration_ms=max_audio_duration_ms,
                                            normalize=Normalize(mean=[51.55220031738281], std=[20.79323387145996]))
                        if len(self.preds) == self.keep_preds_size:
                            del self.preds[0]
                            del self.probs[0]

                        # print(self.preds)
                        self.preds.append(pred_id)
                        self.probs.append(prob)

                        frqs = Counter(self.preds)
                        final_pred_id = frqs.most_common(1)[0][0]
                        cnt = 0
                        avg = 0
                        for i, prob in enumerate(self.probs):
                            if self.preds[i] == final_pred_id:
                                avg += self.probs[i]
                                cnt += 1
                        avg_prob = (avg / cnt) * 100

                        self.final_prediction = f"{self.idx_to_class[pred_id]} : {int(prob*100)}%"
                        print(self.final_prediction)
                        self.buffer = None
                self.rate = 44100
                self.fftx, self.fft = getFFT(self.dataa, self.rate)
                # if self.keepRecording:
                #     self.stream_thread_new()
                # else:
                #     self.stream.close()
                #     self.p.terminate()
                #     print(" -- stream STOPPED")
                # self.chunksRead += 1

        except:
            (type, value, traceback) = sys.exc_info()
            sys.stdout.write(str(type))
            sys.stdout.write(str(value))
            sys.stdout.write(str(traceback.format_exc()))
            
    def stop(self):
        sys.stdout.write('THREAD STOPPED')
        self.running = False


class StreamController(QtWidgets.QWidget):
    def __init__(self):
        super(StreamController, self).__init__()
        self.readdata = np.zeros((444444), dtype=np.int32)
        self.CHUNK = 1024
        self.CHANNELS = 1
        self.RATE = 44100
        self.FORMAT = pyaudio.paInt16 
        self.frames = []       
    def setup_stream(self):
        
        # self.wf = wave.open('/home/bisag/Yogesh/audio/bfsr_chiloda_old/ZOOM0309.WAV')
        # self.p = pyaudio.PyAudio()
        # self.stream = self.p.open(
        #    format = self.p.get_format_from_width(self.wf.getsampwidth()),
        #    channels = self.wf.getnchannels(),
        #    rate = self.wf.getframerate(),
        #    output = True
        # )
        self.audio = pyaudio.PyAudio()
        # self.audio = '/home/bisag/Yogesh/audio/bfsr_chiloda_old/ZOOM0309.WAV'
        # self.audio = 
        self.stream = self.audio.open(format=self.FORMAT,  channels=self.CHANNELS, rate=self.RATE, 
                            input=True, frames_per_buffer=self.CHUNK)

        self.micthread = MicThread(self)
        self.micthread.start()
        

    def append(self, vals):
        vals = np.frombuffer(vals, 'int16')
        c = self.CHUNK
        self.readdata[:-c] = self.readdata[c:]
        self.readdata[-c:] = vals
        
    # def breakdown_stream(self):
    #     self.micthread.terminate()
    #     self.stream.stop_stream()
    #     self.stream.close()
    #     self.audio.terminate()
    #     loop = QtCore.QEventLoop()
    #     QtCore.QTimer.singleShot(400, loop.quit)
    #     loop.exec_()
        

class StreamViz(QtWidgets.QWidget):
    def __init__(self):
        super(StreamViz, self).__init__()
        self.show()
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update_streamplot)
        self.timer.start(10) 
        
        self.l = QtGui.QVBoxLayout()
        self.setLayout(self.l)
        self.p = pyqtgraph.PlotWidget()
        self.l.addWidget(self.p)
        self.sc = StreamController()
        self.l.addWidget(self.sc)
        self.p.plotItem.setRange(yRange=[-30000, 30000])
        pen = pyqtgraph.mkPen(color='b') 
        self.pdataitem = self.p.plot(self.sc.readdata,pen =pen)
        self.sc.setup_stream()
        
        # self.startstop_button = QtWidgets.QPushButton('Stop')
        # self.startstop_button.pressed.connect(self.startstop)
        # self.startstop_button.status = 1
        # self.l.addWidget(self.startstop_button)
        
    # def startstop(self):
    #     b = self.startstop_button
    #     b.setEnabled(False)
    #     if b.status:
    #         self.sc.breakdown_stream()
    #         b.setText('Start')
    #         b.status = 0
    #     else:
    #         self.sc.setup_stream()
    #         b.setText('Stop')
    #         b.status = 1
    #     b.setEnabled(True)
        
    # def closeEvent(self, event):
    #     if self.startstop_button.status:
    #         self.sc.breakdown_stream()
    #     event.accept()        

    def update_streamplot(self):
        self.pdataitem.setData(self.sc.readdata)

    
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    s = StreamViz()
    sys.exit(app.exec_())