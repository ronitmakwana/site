import torch
from torch import nn
try:
    from dataset_utils import BFSRAudio
except:
    from .dataset_utils import BFSRAudio
from torchvision.transforms import Normalize


class AudioCNNClassifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=8, kernel_size=(5, 5), stride=(2, 2), padding=2),
            nn.ReLU(),
            nn.BatchNorm2d(num_features=8),

            nn.Conv2d(in_channels=8, out_channels=16, kernel_size=(3, 3), stride=(2, 2), padding=1),
            nn.ReLU(),
            nn.BatchNorm2d(num_features=16),

            nn.Conv2d(in_channels=16, out_channels=32, kernel_size=(3, 3), stride=(2, 2), padding=1),
            nn.ReLU(),
            nn.BatchNorm2d(num_features=32),

            nn.Conv2d(in_channels=32, out_channels=64, kernel_size=(3, 3), stride=(2, 2), padding=1),
            nn.ReLU(),
            nn.BatchNorm2d(num_features=64),

            nn.AdaptiveAvgPool2d(output_size=1),
            nn.Flatten(),
            nn.Linear(in_features=64, out_features=2)
        )

    def forward(self, x):
        x = self.cnn(x)
        return x


@torch.no_grad()
def infer(classifier: nn.Module, data, input_sr, desired_sr, max_audio_duration_ms, normalize: Normalize, device='cpu'):
    classifier.eval()
    classifier = classifier.to(device)

    spectrogram = BFSRAudio.preprocess(audio=data,
                                       sr=input_sr,
                                       desired_sr=desired_sr,
                                       max_audio_duration_ms=max_audio_duration_ms)

    transformed_audio = normalize(spectrogram).unsqueeze(0).to(device)
    transformed_audio = transformed_audio.to(torch.float32)

    outs = classifier(transformed_audio)
    _, pred_id = torch.max(outs, 1)
    probs = torch.softmax(outs, dim=1)[0].detach()
    return probs[pred_id].item(), int(pred_id.detach())

if __name__ == '__main__':
    model = AudioCNNClassifier()
    x = torch.randn(1,1,128,1251)
    print(sum(p.numel() for p in model.parameters() if p.requires_grad))
    print(model(x).shape)
