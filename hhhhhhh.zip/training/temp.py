import pickle

y = pickle.load(open('data_y.pkl', 'rb'))


new_y = list(map(lambda label_id: 0 if label_id < 2 else 1, y))

for k, k_updated in zip(y, new_y):
    res =  0 if k < 2 else 1
    if res != k_updated:
        print('Not proper')
        exit()

pickle.dump(new_y, open('data_y_v3.pkl', 'wb'))


