from PyQt5.QtWidgets import QWidget, QMessageBox, QDialog
from PyQt5.QtCore import qDebug, QRect, pyqtSignal, Qt
from PyQt5.QtGui import QPixmap

from ui_CameraView import Ui_CameraView
from CaptureThread import CaptureThread
from ImageProcessingSettingsDialog import ImageProcessingSettingsDialog
from ProcessingThread import ProcessingThread
from Structures import *
import datetime
import numpy as np
import os
class CameraView(QWidget, Ui_CameraView):
    newImageProcessingFlags = pyqtSignal(ImageProcessingFlags)
    setROI = pyqtSignal(QRect)

    def __init__(self, parent, deviceUrl, sharedImageBuffer, cameraId):
        super(CameraView, self).__init__(parent)
        self.sharedImageBuffer = sharedImageBuffer
        self.cameraId = cameraId
        # Create image processing settings dialog
        self.imageProcessingSettingsDialog = ImageProcessingSettingsDialog(self)
        # Setup UI
        self.setupUi(self)
        # Save Device Url
        self.deviceUrl = deviceUrl
        # Initialize internal flag
        self.isCameraConnected = False
        # Set initial GUI state
        self.frameLabel.setText("No camera connected.")
        # self.imageBufferBar.setValue(0)
        # self.imageBufferLabel.setText("[000/000]")
        # self.captureRateLabel.setText("")
        # self.processingRateLabel.setText("")
        # self.deviceUrlLabel.setText("")
        # self.cameraResolutionLabel.setText("")
        # self.roiLabel.setText("")
        # self.mouseCursorPosLabel.setText("")
        # self.clearImageBufferButton.setDisabled(True)
        # Initialize ImageProcessingFlags structure
        self.imageProcessingFlags = ImageProcessingFlags()
        # Connect signals/slots
        # self.clearImageBufferButton.released.connect(self.clearImageBuffer)
        self.frameLabel.onMouseMoveEvent.connect(self.updateMouseCursorPosLabel)
        self.frameLabel.menu.triggered.connect(self.handleContextMenuAction)
        # self.startButton.released.connect(self.startThread)
        # self.pauseButton.released.connect(self.pauseThread)
        self.pushButton.released.connect(self.openLogFolder)

    def delete(self):
        if self.isCameraConnected:
            # Stop processing thread
            if self.processingThread.isRunning():
                self.stopProcessingThread()
            # Stop capture thread
            if self.captureThread.isRunning():
                self.stopCaptureThread()

            # Automatically start frame processing (for other streams)
            if self.sharedImageBuffer.isSyncEnabledForDeviceUrl(self.deviceUrl):
                self.sharedImageBuffer.setSyncEnabled(True)

            # Disconnect camera
            if self.captureThread.disconnectCamera():
                qDebug("[%s] Camera successfully disconnected." % self.deviceUrl)
            else:
                qDebug("[%s] WARNING: Camera already disconnected." % self.deviceUrl)

    def afterCaptureThreadFinshed(self):
        # Delete Buffer
        self.sharedImageBuffer.removeByDeviceUrl(self.deviceUrl)

    def afterProcessingThreadFinshed(self):
        qDebug("[%s] WARNING: SQL already disconnected." % self.deviceUrl)

    def connectToCamera(self, dropFrameIfBufferFull, apiPreference, capThreadPrio,
                        procThreadPrio, enableFrameProcessing, width, height):
        # Set frame label text
        if self.sharedImageBuffer.isSyncEnabledForDeviceUrl(self.deviceUrl):
            self.frameLabel.setText("Camera connected. Waiting...")
        else:
            self.frameLabel.setText("Connecting to camera...")

        # Create capture thread
        self.captureThread = CaptureThread(self.sharedImageBuffer, self.deviceUrl, dropFrameIfBufferFull,
                                           apiPreference, width, height)
        # Attempt to connect to camera
        if self.captureThread.connectToCamera():
            # Create processing thread
            self.processingThread = ProcessingThread(self.sharedImageBuffer, self.deviceUrl, self.cameraId)

            # Setup signal/slot connections
            self.processingThread.newFrame.connect(self.updateFrame)
            self.processingThread.updateStatisticsInGUI.connect(self.updateProcessingThreadStats)
            self.captureThread.updateStatisticsInGUI.connect(self.updateCaptureThreadStats)
            self.imageProcessingSettingsDialog.newImageProcessingSettings.connect(
                self.processingThread.updateImageProcessingSettings)
            self.newImageProcessingFlags.connect(self.processingThread.updateImageProcessingFlags)
            self.setROI.connect(self.processingThread.setROI)

            # Remove imageBuffer from shared buffer by deviceUrl after captureThread stop/finished
            self.captureThread.finished.connect(self.afterCaptureThreadFinshed)
            self.processingThread.finished.connect(self.afterProcessingThreadFinshed)

            # Only enable ROI setting/resetting if frame processing is enabled
            if enableFrameProcessing:
                self.frameLabel.newMouseData.connect(self.newMouseData)

            # Set initial data in processing thread
            self.setROI.emit(
                QRect(0, 0, self.captureThread.getInputSourceWidth(), self.captureThread.getInputSourceHeight()))
            self.newImageProcessingFlags.emit(self.imageProcessingFlags)
            self.imageProcessingSettingsDialog.updateStoredSettingsFromDialog()

            # Start capturing frames from camera
            self.captureThread.start(capThreadPrio)
            # Start processing captured frames (if enabled)
            if enableFrameProcessing:
                self.processingThread.start(procThreadPrio)

            # Setup imageBufferBar with minimum and maximum values
            # self.imageBufferBar.setMinimum(0)
            # self.imageBufferBar.setMaximum(self.sharedImageBuffer.getByDeviceUrl(self.deviceUrl).maxSize())

            # Enable "Clear Image Buffer" push button
            # self.clearImageBufferButton.setEnabled(True)

            # Set text in labels
            # self.deviceUrlLabel.setText(self.deviceUrl)
            # self.cameraResolutionLabel.setText("%dx%d" % (self.captureThread.getInputSourceWidth(),
                                                        #   self.captureThread.getInputSourceHeight()))
            # Set internal flag and return
            self.isCameraConnected = True
            # Set frame label text
            if not enableFrameProcessing:
                self.frameLabel.setText("Frame processing disabled.")
            return True
        # Failed to connect to camera
        else:
            return False

    def stopCaptureThread(self):
        qDebug("[%s] About to stop capture thread..." % self.deviceUrl)
        self.captureThread.stop()
        self.sharedImageBuffer.wakeAll()  # This allows the thread to be stopped if it is in a wait-state
        # Take one frame off a FULL queue to allow the capture thread to finish
        if self.sharedImageBuffer.getByDeviceUrl(self.deviceUrl).isFull():
            self.sharedImageBuffer.getByDeviceUrl(self.deviceUrl).get()
        self.captureThread.wait()
        qDebug("[%s] Capture thread successfully stopped." % self.deviceUrl)

    def stopProcessingThread(self):
        qDebug("[%s] About to stop processing thread..." % self.deviceUrl)
        self.processingThread.stop()
        self.sharedImageBuffer.wakeAll()  # This allows the thread to be stopped if it is in a wait-state
        self.processingThread.wait()
        qDebug("[%s] Processing thread successfully stopped." % self.deviceUrl)

    def startThread(self):
        pass

    def openLogFolder(self):
        os.system('nautilus ./logs')

    def pauseThread(self):
        pass

    def updateCaptureThreadStats(self, statData):
        imageBuffer = self.sharedImageBuffer.getByDeviceUrl(self.deviceUrl)
        # Show [number of images in buffer / image buffer size] in imageBufferLabel
        # self.imageBufferLabel.setText("[%d/%d]" % (imageBuffer.size(), imageBuffer.maxSize()))
        # Show percentage of image buffer full in imageBufferBar
        # self.imageBufferBar.setValue(imageBuffer.size())

        # Show processing rate in captureRateLabel
        # self.captureRateLabel.setText("{:>6,.2f} fps".format(statData.averageFPS))
        # Show number of frames captured in nFramesCapturedLabel
        # self.nFramesCapturedLabel.setText("[%d]" % statData.nFramesProcessed)
        pass

    def updateProcessingThreadStats(self, statData):
        # Show processing rate in processingRateLabel
        # self.processingRateLabel.setText("{:>6,.2f} fps".format(statData.averageFPS))
        # # Show ROI information in roiLabel
        # self.roiLabel.setText("(%d,%d) %dx%d" % (self.processingThread.getCurrentROI().x(),
        #                                          self.processingThread.getCurrentROI().y(),
        #                                          self.processingThread.getCurrentROI().width(),
        #                                          self.processingThread.getCurrentROI().height()))
        # # Show number of frames processed in nFramesProcessedLabel
        # self.nFramesProcessedLabel.setText("[%d]" % statData.nFramesProcessed)
        pass

    def updateFrame(self, frame):
        # from CaptureThread import LOG_1, LOG_5, LOG_30, frame_idx, LOG_AVG
        from CaptureThread import FRAME_PREDS
        # Display frame
        # class_names = ['person', 'animal', 'vehicle']
        self.frameLabel.setPixmap(
            QPixmap.fromImage(frame).scaled(self.frameLabel.width(), self.frameLabel.height(), Qt.KeepAspectRatio))
        self.frame_preds_label.setText("Person - {}  |  Animal - {}  |  Vehicle - {}".format(FRAME_PREDS[0], FRAME_PREDS[1], FRAME_PREDS[2]))
        '''
        if int(frame_idx) % 30 == 0:
            log1_1_count = (100 * np.count_nonzero(LOG_1 >= 1, axis = 0) / LOG_1.shape[0]).astype(int)
            log1_2_count = (100 * np.count_nonzero(LOG_1 >= 2, axis = 0) / LOG_1.shape[0]).astype(int)
            log1_3_count = (100 * np.count_nonzero(LOG_1 >= 3, axis = 0) / LOG_1.shape[0]).astype(int)
            log1_4_count = (100 * np.count_nonzero(LOG_1 >= 4, axis = 0) / LOG_1.shape[0]).astype(int)
            log1_5_count = (100 * np.count_nonzero(LOG_1 >= 5, axis = 0) / LOG_1.shape[0]).astype(int)

            log5_1_count = (100 * np.count_nonzero(LOG_5 >= 1, axis = 0) / LOG_5.shape[0]).astype(int)
            log5_2_count = (100 * np.count_nonzero(LOG_5 >= 2, axis = 0) / LOG_5.shape[0]).astype(int)
            log5_3_count = (100 * np.count_nonzero(LOG_5 >= 3, axis = 0) / LOG_5.shape[0]).astype(int)
            log5_4_count = (100 * np.count_nonzero(LOG_5 >= 4, axis = 0) / LOG_5.shape[0]).astype(int)
            log5_5_count = (100 * np.count_nonzero(LOG_5 >= 5, axis = 0) / LOG_5.shape[0]).astype(int)

            log30_1_count = (100 * np.count_nonzero(LOG_30 >= 1, axis = 0) / LOG_30.shape[0]).astype(int)
            log30_2_count = (100 * np.count_nonzero(LOG_30 >= 2, axis = 0) / LOG_30.shape[0]).astype(int)
            log30_3_count = (100 * np.count_nonzero(LOG_30 >= 3, axis = 0) / LOG_30.shape[0]).astype(int)
            log30_4_count = (100 * np.count_nonzero(LOG_30 >= 4, axis = 0) / LOG_30.shape[0]).astype(int)
            log30_5_count = (100 * np.count_nonzero(LOG_30 >= 5, axis = 0) / LOG_30.shape[0]).astype(int)

            log_avg_count = (100 * LOG_AVG / frame_idx).astype(int)

            self.log1_person.setText("Person | 1: {}, 2: {}, 3: {}, 4: {}, >5: {}".format(log1_1_count[0], log1_2_count[0], log1_3_count[0], log1_4_count[0], log1_5_count[0]))
            self.log5_person.setText("Person | 1: {}, 2: {}, 3: {}, 4: {}, >5: {}".format(log5_1_count[0], log5_2_count[0], log5_3_count[0], log5_4_count[0], log5_5_count[0]))
            self.log30_person.setText("Person | 1: {}, 2: {}, 3: {}, 4: {}, >5: {}".format(log30_1_count[0], log30_2_count[0], log30_3_count[0], log30_4_count[0], log30_5_count[0]))

            self.log1_animal.setText("Animal | 1: {}, 2: {}, 3: {}, 4: {}, >5: {}".format(log1_1_count[1], log1_2_count[1], log1_3_count[1], log1_4_count[1], log1_5_count[1]))
            self.log5_animal.setText("Animal | 1: {}, 2: {}, 3: {}, 4: {}, >5: {}".format(log5_1_count[1], log5_2_count[1], log5_3_count[1], log5_4_count[1], log5_5_count[1]))
            self.log30_animal.setText("Animal | 1: {}, 2: {}, 3: {}, 4: {}, >5: {}".format(log30_1_count[1], log30_2_count[1], log30_3_count[1], log30_4_count[1], log30_5_count[1]))

            self.log1_vehicle.setText("Vehicle | 1: {}, 2: {}, 3: {}, 4: {}, >5: {}".format(log1_1_count[2], log1_2_count[2], log1_3_count[2], log1_4_count[2], log1_5_count[2]))
            self.log5_vehicle.setText("Vehicle | 1: {}, 2: {}, 3: {}, 4: {}, >5: {}".format(log5_1_count[2], log5_2_count[2], log5_3_count[2], log5_4_count[2], log5_5_count[2]))
            self.log30_vehicle.setText("Vehicle | 1: {}, 2: {}, 3: {}, 4: {}, >5: {}".format(log30_1_count[2], log30_2_count[2], log30_3_count[2], log30_4_count[2], log30_5_count[2]))
            
            self.log_avg_person.setText("Person: {}".format(log_avg_count[0]))
            self.log_avg_animal.setText("Animal: {}".format(log_avg_count[1]))
            self.log_avg_vehicle.setText("Vehicle: {}".format(log_avg_count[2]))
        '''

    def clearImageBuffer(self):
        pass
        '''
        if self.sharedImageBuffer.getByDeviceUrl(self.deviceUrl).clear():
            qDebug("[%s] Image buffer successfully cleared." % self.deviceUrl)
        else:
            qDebug("[%s] WARNING: Could not clear image buffer." % self.deviceUrl)
        '''

    def setImageProcessingSettings(self):
        # Prompt user:
        # If user presses OK button on dialog, update image processing settings
        if self.imageProcessingSettingsDialog.exec() == QDialog.Accepted:
            self.imageProcessingSettingsDialog.updateStoredSettingsFromDialog()
        # Else, restore dialog state
        else:
            self.imageProcessingSettingsDialog.updateDialogSettingsFromStored()

    def updateMouseCursorPosLabel(self):
        '''
        # Update mouse cursor position in mouseCursorPosLabel
        self.mouseCursorPosLabel.setText(
            "(%d,%d)" % (self.frameLabel.getMouseCursorPos().x(), self.frameLabel.getMouseCursorPos().y()))

        # Show pixel cursor position if camera is connected (image is being shown)
        if self.frameLabel.pixmap():
            # Scaling factor calculation depends on whether frame is scaled to fit label or not
            if not self.frameLabel.hasScaledContents():
                xScalingFactor = (self.frameLabel.getMouseCursorPos().x() - (
                        self.frameLabel.width() - self.frameLabel.pixmap().width()) / 2) / self.frameLabel.pixmap().width()
                yScalingFactor = (self.frameLabel.getMouseCursorPos().y() - (
                        self.frameLabel.height() - self.frameLabel.pixmap().height()) / 2) / self.frameLabel.pixmap().height()
            else:
                xScalingFactor = self.frameLabel.getMouseCursorPos().x() / self.frameLabel.width()
                yScalingFactor = self.frameLabel.getMouseCursorPos().y() / self.frameLabel.height()

            self.mouseCursorPosLabel.setText(
                '%s [%d,%d]' % (self.mouseCursorPosLabel.text(),
                                xScalingFactor * self.processingThread.getCurrentROI().width(),
                                yScalingFactor * self.processingThread.getCurrentROI().height()))
        '''
        pass

    def newMouseData(self, mouseData):
        # Local variable(s)
        selectionBox = QRect()
        # Set ROI
        if mouseData.leftButtonRelease and self.frameLabel.pixmap():
            # Selection box calculation depends on whether frame is scaled to fit label or not
            if not self.frameLabel.hasScaledContents():
                xScalingFactor = (mouseData.selectionBox.x() - (
                        self.frameLabel.width() - self.frameLabel.pixmap().width()) / 2) / self.frameLabel.pixmap().width()
                yScalingFactor = (mouseData.selectionBox.y() - (
                        self.frameLabel.height() - self.frameLabel.pixmap().height()) / 2) / self.frameLabel.pixmap().height()
                wScalingFactor = self.processingThread.getCurrentROI().width() / self.frameLabel.pixmap().width()
                hScalingFactor = self.processingThread.getCurrentROI().height() / self.frameLabel.pixmap().height()
            else:
                xScalingFactor = mouseData.selectionBox.x() / self.frameLabel.width()
                yScalingFactor = mouseData.selectionBox.y() / self.frameLabel.height()
                wScalingFactor = self.processingThread.getCurrentROI().width() / self.frameLabel.width()
                hScalingFactor = self.processingThread.getCurrentROI().height() / self.frameLabel.height()

            # Set selection box properties (new ROI)
            selectionBox.setX(
                xScalingFactor * self.processingThread.getCurrentROI().width() + self.processingThread.getCurrentROI().x())
            selectionBox.setY(
                yScalingFactor * self.processingThread.getCurrentROI().height() + self.processingThread.getCurrentROI().y())
            selectionBox.setWidth(wScalingFactor * mouseData.selectionBox.width())
            selectionBox.setHeight(hScalingFactor * mouseData.selectionBox.height())

            # Check if selection box has NON-ZERO dimensions
            if selectionBox.width() != 0 and selectionBox.height() != 0:
                # Selection box can also be drawn from bottom-right to top-left corner
                if selectionBox.width() < 0:
                    x_temp = selectionBox.x()
                    width_temp = selectionBox.width()
                    selectionBox.setX(x_temp + selectionBox.width())
                    selectionBox.setWidth(width_temp * -1)
                if selectionBox.height() < 0:
                    y_temp = selectionBox.y()
                    height_temp = selectionBox.height()
                    selectionBox.setY(y_temp + selectionBox.height())
                    selectionBox.setHeight(height_temp * -1)

                # Check if selection box is not outside window
                if (selectionBox.x() < 0 or selectionBox.y() < 0 or
                        selectionBox.x() + selectionBox.width() > self.processingThread.getCurrentROI().x() + self.processingThread.getCurrentROI().width() or
                        selectionBox.y() + selectionBox.height() > self.processingThread.getCurrentROI().y() + self.processingThread.getCurrentROI().height() or
                        selectionBox.x() < self.processingThread.getCurrentROI().x() or
                        selectionBox.y() < self.processingThread.getCurrentROI().y()):
                    # Display error message
                    QMessageBox.warning(self,
                                        "ERROR:",
                                        "Selection box outside range. Please try again.")
                # Set ROI
                else:
                    self.setROI.emit(selectionBox)

    def handleContextMenuAction(self, action):
        if action.text() == "Reset ROI":
            self.setROI.emit(
                QRect(0, 0, self.captureThread.getInputSourceWidth(), self.captureThread.getInputSourceHeight()))
        elif action.text() == "Scale to Fit Frame":
            self.frameLabel.setScaledContents(action.isChecked())
        elif action.text() == "Grayscale":
            self.imageProcessingFlags.grayscaleOn = action.isChecked()
            self.newImageProcessingFlags.emit(self.imageProcessingFlags)
        elif action.text() == "Smooth":
            self.imageProcessingFlags.smoothOn = action.isChecked()
            self.newImageProcessingFlags.emit(self.imageProcessingFlags)
        elif action.text() == "Dilate":
            self.imageProcessingFlags.dilateOn = action.isChecked()
            self.newImageProcessingFlags.emit(self.imageProcessingFlags)
        elif action.text() == "Erode":
            self.imageProcessingFlags.erodeOn = action.isChecked()
            self.newImageProcessingFlags.emit(self.imageProcessingFlags)
        elif action.text() == "Flip":
            self.imageProcessingFlags.flipOn = action.isChecked()
            self.newImageProcessingFlags.emit(self.imageProcessingFlags)
        elif action.text() == "Canny":
            self.imageProcessingFlags.cannyOn = action.isChecked()
            self.newImageProcessingFlags.emit(self.imageProcessingFlags)
        elif action.text() == "Settings...":
            self.setImageProcessingSettings()
