from PyQt5.QtCore import QThread, QTime, QMutexLocker, QMutex, pyqtSignal, qDebug
from PyQt5.QtWidgets import QMessageBox
import cv2
from queue import Queue
import os
from Structures import *
from Config import *
import subprocess
import ctypes
from infer2 import YoloV4TRT
from yolov5_detect import YoLov5TRT
import time
import datetime
import numpy as np
import sounddevice as sd
import soundfile as sf
import requests
import threading
import RPi.GPIO as GPIO
from Config import VIBRATE_FLAG, BUZZER_FLAG, SPEAKER_FLAG

if BUZZER_FLAG:
    buzzer_pin = 29
    try:
        GPIO.setmode(GPIO.BOARD)
        GPIO.setup(buzzer_pin,GPIO.OUT)
    except:
        pass

def vibrate():
    try:
        response = requests.get('http://10.42.0.59:8000',timeout=2)
    except:
        pass

def vibrate2():
    try:
        response = requests.get('http://10.42.0.9:8000',timeout=2)
    except:
        pass

def play_audio():
    try:
        os.system('aplay /home/user/Documents/Prekshak/beep.wav')
    except:
        pass

def alert():
    try:
        GPIO.output(buzzer_pin,GPIO.HIGH)
        time.sleep(1)
        GPIO.output(buzzer_pin,GPIO.LOW)
        time.sleep(1)
    except:
        pass

# frame_counts = [1800, 9000, 54000]
frame_idx = 1
# LOG_AVG = np.zeros(3) # Average preds
# LOG_1 = np.zeros((1, 3)) # 1 min
# LOG_5 = np.zeros((1, 3)) # 5 min
# LOG_30 = np.zeros((1, 3)) # 30 min

FRAME_PREDS = 0

class CaptureThread(QThread):
    updateStatisticsInGUI = pyqtSignal(ThreadStatisticsData)
    end = pyqtSignal()

    def __init__(self, sharedImageBuffer, deviceUrl, dropFrameIfBufferFull, apiPreference, width, height, parent=None):
        super(CaptureThread, self).__init__(parent)
        self.cap = cv2.VideoCapture()
        self.t = QTime()
        self.doStopMutex = QMutex()
        self.fps = Queue()
        # Save passed parameters
        self.sharedImageBuffer = sharedImageBuffer
        self.dropFrameIfBufferFull = dropFrameIfBufferFull
        self.deviceUrl = deviceUrl
        self._deviceUrl = int(deviceUrl) if deviceUrl.isdigit() else deviceUrl   #0
        self.localVideo = True if os.path.exists(self._deviceUrl) else False
        self.apiPreference = apiPreference
        self.width = width
        self.height = height
        # Initialize variables(s)
        self.captureTime = 0
        self.doStop = False
        self.sampleNumber = 0
        self.fpsSum = 0.0
        self.statsData = ThreadStatisticsData()
        self.defaultTime = 0

        self.yolo_flag = 0
        self.audio_flag = False
        self.nb_skip = 2
        self.boxes = None
        # load custom plugins
        # engine_file_path = "weights/yolov4-tiny.trt"
        # self.detector = YoloV4TRT(engine_file_path, 416, ['person', 'animal', 'vehicle'])
        engine_file_path = "weights/prekshak_yolov5s.engine"
        plugin_library_path = "weights/libmyplugins.so"
        self.detector = YoLov5TRT(engine_file_path, plugin_library_path, ['person', 'animal', 'vehicle'])

    def run(self):
        pause = False
        while True:
            ################################
            # Stop thread if doStop = TRUE #
            ################################
            self.doStopMutex.lock()
            if self.doStop:
                self.doStop = False
                self.doStopMutex.unlock()
                break
            self.doStopMutex.unlock()
            ################################
            ################################

            # Synchronize with other streams (if enabled for this stream)
            self.sharedImageBuffer.sync(self.deviceUrl)

            # Capture frame ( if available)
            if not self.cap.grab():
                if pause or not self.localVideo:
                    continue
                # Video End
                pause = True
                self.end.emit()
                continue

            # Retrieve frame
            _, self.grabbedFrame = self.cap.retrieve()
            if self.yolo_flag == 0:
                # self.boxes = self.detector.infer(self.grabbedFrame) # YoloV4
                self.grabbedFrame, self.boxes, self.class_ids, self.scores = self.detector.infer(self.grabbedFrame) # YoloV5
            if self.yolo_flag == self.nb_skip:
                self.yolo_flag = -1
            self.yolo_flag += 1

            # object_count = self.generate_metadata_yolov4(self.boxes[0]) # YoloV4
            object_count = self.generate_metadata_yolov5(self.class_ids) # YoloV5
            # if object_count[0] > 0:
            #     filename = 'beep.wav'
            #     # Extract data and sampling rate from file
            #     data, fs = sf.read(filename, dtype='float32')  
            #     sd.play(data, fs)
            #     status = sd.wait()  # Wait until file is done playing                

            '''
            global LOG_1, LOG_5, LOG_30, frame_counts, frame_idx, LOG_AVG
            frame_idx += 1
            LOG_AVG += np.array(list(map(lambda count: 1 if count > 0 else 0, object_count)))
            # print(frame_idx)
            if frame_idx % 30 == 0:
                f = open('logs/' + datetime.date.today().isoformat(),'a')
                time_now = datetime.datetime.now()
                time_str = time_now.strftime("%H") + ':' + time_now.strftime("%M") + ':' + time_now.strftime("%S") + ' '
                f.write(time_str + str(dict(zip(self.detector.class_names, object_count))) + os.linesep)
                f.close()

            LOG_1 = np.vstack((LOG_1, np.array(object_count)))
            LOG_5 = np.vstack((LOG_5, np.array(object_count)))
            LOG_30 = np.vstack((LOG_30, np.array(object_count)))

            if frame_counts[0] == LOG_1.shape[0]:
                LOG_1 = LOG_1[1:,:]
            if frame_counts[1] == LOG_5.shape[0]:
                LOG_5 = LOG_5[1:,:]
            if frame_counts[2] == LOG_30.shape[0]:
                LOG_30 = LOG_30[1:,:]
            '''

            global FRAME_PREDS , frame_idx
            if (object_count[0] > 0) and (frame_idx % 300 ==0) and BUZZER_FLAG:
                thread1= threading.Thread(target=alert)
                thread1.start()
            if (object_count[0] > 0) and (frame_idx % 300 ==0) and VIBRATE_FLAG:
                thread2 = threading.Thread(target=vibrate)
                thread2.start()
            if (object_count[0] > 0) and (frame_idx % 300 ==0) and VIBRATE_FLAG:
                thread4 = threading.Thread(target=vibrate2)
                thread4.start()
            if object_count[0] > 0 and (frame_idx % 300 == 0) and (not self.audio_flag) and SPEAKER_FLAG:
                # filename = 'beep.wav'
                # # Extract data and sampling rate from file
                # data, fs = sf.read(filename, dtype='float32')  
                # sd.play(data, fs)
                # status = sd.wait()  # Wait until file is done playing
                thread3 = threading.Thread(target=play_audio)
                thread3.start()
                self.audio_flag = True
                print('Audio True')

            if frame_idx % 360 == 0 and SPEAKER_FLAG:
                self.audio_flag = False

            frame_idx += 1

            # self.grabbedFrame = self.detector.plot_boxes_cv2(self.grabbedFrame, self.boxes[0]) # YoloV4
            self.grabbedFrame = self.detector.plot_boxes(self.grabbedFrame, self.boxes, self.class_ids, self.scores) # YoloV5

            FRAME_PREDS = object_count
            #_ = self.detector.infer(self.grabbedFrame)
            # print('Total time: {:.6f} s'.format(time.time() - start))
            

            # Add frame to buffer
            self.sharedImageBuffer.getByDeviceUrl(self.deviceUrl).add(self.grabbedFrame, self.dropFrameIfBufferFull)

            self.statsData.nFramesProcessed += 1
            # Inform GUI of updated statistics
            self.updateStatisticsInGUI.emit(self.statsData)

            # Limit fps
            delta = self.defaultTime - self.t.elapsed()
            # delta = self.defaultTime - self.captureTime
            if delta > 0:
                self.msleep(delta)
            # Save capture time
            self.captureTime = self.t.elapsed()

            # Update statistics
            self.updateFPS(self.captureTime)
            print(self.statsData.averageFPS)

            # Start timer (used to calculate capture rate)
            self.t.start()

        qDebug("Stopping capture thread...")

    def generate_metadata_yolov4(self, preds):
        meta = [0]*3
        for pred in preds:
            meta[pred[6]] += 1
        return meta

    def generate_metadata_yolov5(self, result_class_ids):
        meta = [0]*3
        for class_id in result_class_ids:
            meta[int(class_id)] += 1
        return meta

    def stop(self):
        with QMutexLocker(self.doStopMutex):
            self.doStop = True

    def connectToCamera(self):
        # gst_elements = str(subprocess.check_output('gst-inspect-1.0'))
        # if 'nvcamerasrc' in gst_elements:
        #     # On versions of L4T prior to 28.1, add 'flip-method=2' into gst_str
        #     gst_str = ('nvcamerasrc ! '
        #             'video/x-raw(memory:NVMM), '
        #             'width=(int)2592, height=(int)1458, '
        #             'format=(string)I420, framerate=(fraction)30/1 ! '
        #             'nvvidconv ! '
        #             'video/x-raw, width=(int){}, height=(int){}, '
        #             'format=(string)BGRx ! '
        #             'videoconvert ! appsink').format(self.width, self.height)
        # elif 'nvarguscamerasrc' in gst_elements:
        #     gst_str = ('nvarguscamerasrc ! '
        #             'video/x-raw(memory:NVMM), '
        #             'width=(int)1920, height=(int)1080, '
        #             'format=(string)NV12, framerate=(fraction)30/1 ! '
        #             'nvvidconv flip-method=2 ! '
        #             'video/x-raw, width=(int){}, height=(int){}, '
        #             'format=(string)BGRx ! '
        #             'videoconvert ! appsink').format(self.width, self.height)
        # else:
        #     raise RuntimeError('onboard camera source not found!')
        # Open camera
        camOpenResult = self.cap.open(self._deviceUrl, self.apiPreference)
        # camOpenResult = self.cap.open(self._deviceUrl, cv2.CAP_GSTREAMER)
        # camOpenResult = self.cap.open(self._deviceUrl, cv2.CAP_GSTREAMER)
        # Set resolution
        if self.width != -1:
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
        if self.height != -1:
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)

        if camOpenResult:
            try:
                self.defaultTime = int(1000 / self.cap.get(cv2.CAP_PROP_FPS))
            except:
                self.defaultTime = 40
        # Return result
        return camOpenResult

    def disconnectCamera(self):
        # Camera is connected
        self.detector.destroy()
        if self.cap.isOpened():
            # Disconnect camera
            self.cap.release()
            return True
        # Camera is NOT connected
        else:
            return False

    def isCameraConnected(self):
        return self.cap.isOpened()

    def getInputSourceWidth(self):
        return self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)

    def getInputSourceHeight(self):
        return self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)

    def updateFPS(self, timeElapsed):
        # Add instantaneous FPS value to queue
        if timeElapsed > 0:
            self.fps.put(1000 / timeElapsed)
            # Increment sample Number
            self.sampleNumber += 1

        # Maximum size of queue is DEFAULT_CAPTURE_FPS_STAT_QUEUE_LENGTH
        if self.fps.qsize() > CAPTURE_FPS_STAT_QUEUE_LENGTH:
            self.fps.get()
        # Update FPS value every DEFAULT_CAPTURE_FPS_STAT_QUEUE_LENGTH samples
        if self.fps.qsize() == CAPTURE_FPS_STAT_QUEUE_LENGTH and self.sampleNumber == CAPTURE_FPS_STAT_QUEUE_LENGTH:
            # Empty queue and store sum
            while not self.fps.empty():
                self.fpsSum += self.fps.get()
            # Calculate average FPS
            self.statsData.averageFPS = self.fpsSum / CAPTURE_FPS_STAT_QUEUE_LENGTH
            # Reset sum
            self.fpsSum = 0.0
            # Reset sample Number
            self.sampleNumber = 0
