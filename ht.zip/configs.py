# Gaussian filter to blur the frame, increase size for more blurring
GAUSSIAN_BLUR_KSIZE = (21, 21)

# Factor for merging two nearby contour (blob of detected change)
DILATE_KERNEL_KSIZE = 7

# Number of times to perform above dilate operation on binary change image
DILATE_NB_ITERS = 4

# Subtract current and last nth frame from the current timestep to detect change
# This parameter is highly dependent on movement of the object
# Tune this param depending on the video
PAST_NB_FRAMES = 5


# List of horizontal stripes to black out
# This stripes may show time and inside frame
# E.g. Frame is just an image, which is a 2D array of numbers
# 0 to 43 is one stripe, meaning in our 2d array row 0 to row 43 will be blacked out
# (it's values will be made zero which in turn will look
# like black thin horizontal stripe on top of the image)
# Here 'end' string indicates last row's index in image
# e.g. if image height is 400 pixels, last row's index will be 399
#HORIZONTAL_STRIPE_BLOCK_LIST = [[0, 43], [543, 'end']] # 60
HORIZONTAL_STRIPE_BLOCK_LIST = [[0, 120], [543, 'end']] # 60

# Minimum value to use to threshold the difference image
# Higher value may result in less number of detections
# min: 1, max: 255
MIN_CHANGE_INTENSITY = 20


# Filter out detected boxes if it's less than this value
# Can be tuned to remove noisy detections
MIN_BOX_AREA = 100
