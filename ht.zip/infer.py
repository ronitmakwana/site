"""
An example that uses TensorRT's Python api to make inferences.
"""
import os
import random
import sys
import time

import cv2
import numpy as np
import pycuda.autoinit
import pycuda.driver as cuda
import tensorrt as trt
import torch
import torchvision
import json
from collections import Counter

with open('config.json', 'r') as fp:
    data = json.load(fp)

INPUT_W = data['INPUT_W']
INPUT_H = data['INPUT_H']
CONF_THRESH = data['CONF_THRESH']
IOU_THRESHOLD = data['IOU_THRESHOLD']

stride = [8, 16, 32]
anchors = [[10,13], [16,30], [33,23], [30,61], [62,45], [59,119], [116,90], [156,198], [373,326]]

grids = [[3], [3], [3]]
for i, s in enumerate(stride):
    grids[i].append(INPUT_W/s)
    grids[i].append(INPUT_H/s)

# load custom plugins
engine_file_path = "weights/yolov5s.trt"

# load coco labels
categories = ["person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat", "traffic light",
        "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow",
        "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
        "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove", "skateboard", "surfboard",
        "tennis racket", "bottle", "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple",
        "sandwich", "orange", "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch",
        "potted plant", "bed", "dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard", "cell phone",
        "microwave", "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors", "teddy bear",
        "hair drier", "toothbrush"]

def plot_one_box(x, img, color=None, label=None, line_thickness=None):
    """
    description: Plots one bounding box on image img,
                 this function comes from YoLov5 project.
    param: 
        x:      a box likes [x1,y1,x2,y2]
        img:    a opencv image object
        color:  color to draw rectangle, such as (0,255,0)
        label:  str
        line_thickness: int
    return:
        no return

    """
    tl = (
        line_thickness or round(0.002 * (img.shape[0] + img.shape[1]) / 2) + 1
    )  # line/font thickness
    color = color or [random.randint(0, 255) for _ in range(3)]
    c1, c2 = (int(x[0]), int(x[1])), (int(x[2]), int(x[3]))
    cv2.rectangle(img, c1, c2, color, thickness=tl, lineType=cv2.LINE_AA)
    if label:
        tf = max(tl - 1, 1)  # font thickness
        t_size = cv2.getTextSize(label, 0, fontScale=tl / 3, thickness=tf)[0]
        c2 = c1[0] + t_size[0], c1[1] - t_size[1] - 3
        cv2.rectangle(img, c1, c2, color, -1, cv2.LINE_AA)  # filled
        cv2.putText(
            img,
            label,
            (c1[0], c1[1] - 2),
            0,
            tl / 3,
            [225, 255, 255],
            thickness=tf,
            lineType=cv2.LINE_AA,
        )


class YoLov5TRT(object):
    """
    description: A YOLOv5 class that warps TensorRT ops, preprocess and postprocess ops.
    """

    def __init__(self, engine_file_path, filter_classes = ["person", "car", "dog"]):
        # Create a Context on this device,
        self.cfx = cuda.Device(0).make_context()
        stream = cuda.Stream()
        TRT_LOGGER = trt.Logger(trt.Logger.INFO)
        runtime = trt.Runtime(TRT_LOGGER)

        # Deserialize the engine from file
        with open(engine_file_path, "rb") as f:
            engine = runtime.deserialize_cuda_engine(f.read())
        context = engine.create_execution_context()

        host_inputs = []
        cuda_inputs = []
        host_outputs= []
        cuda_outputs= []
        bindings=[]

        for binding in engine:
            size = trt.volume(engine.get_binding_shape(binding)) * engine.max_batch_size
            dtype = trt.nptype(engine.get_binding_dtype(binding))
            # Allocate host and device buffers
            host_mem = cuda.pagelocked_empty(size, dtype)
            cuda_mem = cuda.mem_alloc(host_mem.nbytes)
            # Append the device buffer to device bindings.
            bindings.append(int(cuda_mem))
            # Append to the appropriate list.
            if engine.binding_is_input(binding):
                host_inputs.append(host_mem)
                cuda_inputs.append(cuda_mem)
            else:
                host_outputs.append(host_mem)
                cuda_outputs.append(cuda_mem)

        # Store
        self.stream = stream
        self.context = context
        self.engine = engine
        self.host_inputs = host_inputs
        self.cuda_inputs = cuda_inputs
        self.host_outputs = host_outputs
        self.cuda_outputs = cuda_outputs
        self.bindings = bindings

        i=0
        self.anchor_mult = torch.zeros((22743, 2), dtype = torch.float32)
        self.x_div = torch.zeros(22743, dtype = torch.float32)
        self.x_add = torch.zeros(22743, dtype = torch.float32)
        self.y_div = torch.zeros(22743, dtype = torch.float32)
        self.y_add = torch.zeros(22743, dtype = torch.float32)
        for n in range(len(grids)):
            for c in range(grids[n][0]):
                anc=anchors[n * grids[n][0] + c]
                for h in range(int(grids[n][1])):
                    for w in range(int(grids[n][2])):
                        self.anchor_mult[i, 0] = anc[0]
                        self.anchor_mult[i, 1] = anc[1]
                        self.x_div[i] = grids[n][1]
                        self.x_add[i] = w
                        self.y_div[i] = grids[n][2]
                        self.y_add[i] = h
                        i+=1
        cat_to_id = {v:k for k, v in enumerate(categories)}
        self.filter_classids = [cat_to_id[class_name] for class_name in filter_classes]

    def infer(self, img):
        # Make self the active context, pushing it on top of the context stack.
        self.cfx.push()
        # Restore
        stream = self.stream
        context = self.context
        engine = self.engine
        host_inputs = self.host_inputs
        cuda_inputs = self.cuda_inputs
        host_outputs = self.host_outputs
        cuda_outputs = self.cuda_outputs
        bindings = self.bindings
        # Do image preprocess
        input_image, image_raw, origin_h, origin_w = self.preprocess_image(img)
        # Copy input image to host buffer
        np.copyto(host_inputs[0], input_image.ravel())
        # Transfer input data  to the GPU.
        cuda.memcpy_htod_async(cuda_inputs[0], host_inputs[0], stream)
        # Run inference.
        context.execute_async(bindings=bindings, stream_handle=stream.handle)
        # Transfer predictions back from the GPU.
        cuda.memcpy_dtoh_async(host_outputs[0], cuda_outputs[0], stream)
        # Synchronize the stream
        stream.synchronize()
        # Remove any context from the top of the context stack, deactivating it.
        self.cfx.pop()
        # Here we use the first row of output in that batch_size = 1
        output = host_outputs[0]
        # Do postprocess
        result_boxes, result_scores, result_classid = self.post_process(
            output, origin_h, origin_w
        )

        obj_dict = self.gen_obj_dict(result_classid)
        # Draw rectangles and labels on the original image
        for i in range(len(result_boxes)):
            box = result_boxes[i]
            plot_one_box(
                box,
                image_raw,
                label="{}:{:.2f}".format(
                    categories[int(result_classid[i])], result_scores[i]
                ),
            )
        # cv2.imwrite('1.jpg', image_raw)
        return obj_dict

    def gen_obj_dict(self, ids):
        mask = torch.zeros(ids.shape, dtype = torch.bool)
        for i in self.filter_classids:
            mask = torch.logical_or(mask, ids == i)
        filtered_ids = list(map(int, ids[mask].tolist()))
        hist = dict(Counter(filtered_ids))
        return {categories[k]: v for k, v in hist.items()}

    def destroy(self):
        # Remove any context from the top of the context stack, deactivating it.
        self.cfx.pop()

    def preprocess_image(self, image_raw):
        """
        description: Read an image from image path, convert it to RGB,
                     resize and pad it to target size, normalize to [0,1],
                     transform to NCHW format.
        param:
            input_image_path: str, image path
        return:
            image:  the processed image
            image_raw: the original image
            h: original height
            w: original width
        """
        # image_raw = cv2.imread(input_image_path)
        h, w, c = image_raw.shape
        image = cv2.cvtColor(image_raw, cv2.COLOR_BGR2RGB)
        # Calculate widht and height and paddings
        r_w = INPUT_W / w
        r_h = INPUT_H / h
        if r_h > r_w:
            tw = INPUT_W
            th = int(r_w * h)
            tx1 = tx2 = ty1 = 0
            ty2 = INPUT_H - th
        else:
            tw = int(r_h * w)
            th = INPUT_H
            ty1 = ty2 = tx1 = 0
            tx2 = INPUT_W - tw
        # Resize the image with long side while maintaining ratio
        image = cv2.resize(image, (tw, th))
        # Pad the short side with (128,128,128)
        image = cv2.copyMakeBorder(
            image, ty1, ty2, tx1, tx2, cv2.BORDER_CONSTANT, (128, 128, 128)
        )
        image = image.astype(np.float32)
        # Normalize to [0,1]
        image /= 255.0
        # HWC to CHW format:
        image = np.transpose(image, [2, 0, 1])
        # CHW to NCHW format
        image = np.expand_dims(image, axis=0)
        # Convert the image to row-major order, also known as "C order":
        image = np.ascontiguousarray(image)
        return image, image_raw, h, w

    def transform_boxes(self, boxes, mask, orig_h, orig_w):
        """
        description:    Convert nx4 boxes from [x, y, w, h] to [x1, y1, x2, y2] where xy1=top-left, xy2=bottom-right
        param:
            origin_h:   height of original image
            origin_w:   width of original image
            x:          A boxes tensor, each row is a box [center_x, center_y, w, h]
        return:
            y:          A boxes tensor, each row is a box [x1, y1, x2, y2]
        """
        ratio = orig_h / INPUT_H if (orig_h / INPUT_H > orig_w / INPUT_W) else orig_w / INPUT_W
        anchor_mult = self.anchor_mult[mask]
        x_div = self.x_div[mask]
        x_add = self.x_add[mask]
        y_div = self.y_div[mask]
        y_add = self.y_add[mask]
        boxes = boxes[mask]

        boxes[:, 2:] *= 2
        boxes[:, 2:] = torch.square(boxes[:, 2:])
        boxes[:, 2:] *= (anchor_mult * ratio)
        boxes[:, 0] = boxes[:, 0]*2 - 0.5 + x_add
        boxes[:, 0] /= x_div
        boxes[:, 0] *= (INPUT_W * ratio)
        boxes[:, 1] = boxes[:, 1]*2 - 0.5 + y_add
        boxes[:, 1] /= y_div
        boxes[:, 1] *= (INPUT_H * ratio)

        boxes[:, 0] -= (boxes[:, 2] / 2)
        boxes[:, 1] -= (boxes[:, 3] / 2)

        boxes[:, 2] += boxes[:, 0]
        boxes[:, 3] += boxes[:, 1]

        return boxes

    def post_process(self, output, orig_h, orig_w):
        """
        description: postprocess the prediction
        param:
            output:     A tensor likes [num_boxes,cx,cy,w,h,conf,cls_id, cx,cy,w,h,conf,cls_id, ...] 
            origin_h:   height of original image
            origin_w:   width of original image
        return:
            result_boxes: finally boxes, a boxes tensor, each row is a box [x1, y1, x2, y2]
            result_scores: finally scores, a tensor, each element is the score correspoing to box
            result_classid: finally classid, a tensor, each element is the classid correspoing to box
        """
        # Get the num of boxes detected
        preds = torch.from_numpy(output).view(-1, len(categories) + 5)
        class_probs = preds[:, 5:]
        obj_probs = preds[:, 4]
        boxes = preds[:, :4]
        
        values, idxs = torch.max(class_probs, 1)
        probs = values*obj_probs
        # Choose those boxes that score > CONF_THRESH
        mask = probs > CONF_THRESH
        probs = probs[mask]
        idxs = idxs[mask]
        # Trandform bbox from [center_x, center_y, w, h] to [x1, y1, x2, y2]
        boxes = self.transform_boxes(boxes, mask, orig_h, orig_w)
        # Do nms
        indices = torchvision.ops.nms(boxes=boxes, scores=probs, iou_threshold=IOU_THRESHOLD)
        result_boxes = boxes[indices, :]
        result_scores = probs[indices]
        result_classid = idxs[indices]
        return result_boxes, result_scores, result_classid
