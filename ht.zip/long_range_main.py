import time
import cv2
# import nms.nms
from configs import *
import numpy as np


def detect_movement(past_frame, cur_frame):
    change = cv2.absdiff(past_frame, cur_frame)
    _, binary_change_img = cv2.threshold(change, MIN_CHANGE_INTENSITY, 255, cv2.THRESH_BINARY)
    # binary_change_img = cv2.erode(binary_change_img,
    #                               kernel=np.ones((3, 3),
    #                                              dtype=np.uint8),
    #                               iterations=3)
    # cv2.imshow('After Erosion', binary_change_img)
    binary_change_img = cv2.dilate(binary_change_img,
                                   kernel=np.ones((DILATE_KERNEL_KSIZE, DILATE_KERNEL_KSIZE),
                                                  dtype=np.uint8),
                                   iterations=DILATE_NB_ITERS)
    # cv2.imshow('After Dilation', binary_change_img)

    contours, _ = cv2.findContours(binary_change_img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    boxes = []
    for points in contours:
        points = np.squeeze(points, axis=1)
        mins = np.min(points, axis=0)
        maxes = np.max(points, axis=0)

        # if detected box's area is greater than minimum threshold then only add to boxes
        if ((maxes[1] - mins[1]) * (maxes[0] - mins[0])) > MIN_BOX_AREA:
            boxes.append([mins[0], mins[1], maxes[0], maxes[1]])
    return binary_change_img, np.array(boxes)


def process_frame(frame):
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    frame = cv2.GaussianBlur(frame, GAUSSIAN_BLUR_KSIZE, 0)
    for stripe in HORIZONTAL_STRIPE_BLOCK_LIST:
        start = stripe[0]
        end = stripe[1]
        if end == 'end':
            end = frame.shape[0]
        frame[start:end, :] = 0
    return frame


def calculate_1d_iou(a1: np.ndarray, a2: np.ndarray, b1: np.ndarray, b2: np.ndarray):
    a1 = a1.reshape(-1, 1)
    a2 = a2.reshape(-1, 1)
    b1 = b1.reshape(1, -1)
    b2 = b2.reshape(1, -1)

    m = a1.shape[0]
    n = b1.shape[1]
    l_a = (a2 - a1)
    l_b = (b2 - b1)
    temp1 = np.concatenate((np.repeat(a1, n, axis=1)[np.newaxis, :], np.repeat(b1, m, axis=0)[np.newaxis, :]), axis=0)
    temp2 = np.concatenate((np.repeat(a2, n, axis=1)[np.newaxis, :], np.repeat(b2, m, axis=0)[np.newaxis, :]), axis=0)
    a_union_b = np.max(temp2, axis=0) - np.min(temp1, axis=0)
    a_inter_b = l_a + l_b - a_union_b
    a_inter_b[a_inter_b < 0] = 0
    return a_inter_b / a_union_b


def merge_boxes(box1, box2):
    xs = [box1[0], box1[2], box2[0], box2[2]]
    ys = [box1[1], box1[3], box2[1], box2[3]]

    return [min(xs), min(ys), max(xs), max(ys)]


def convert_boxes(boxes, to_standard):
    if to_standard:
        boxes[:, 2] -= boxes[:, 0]
        boxes[:, 3] -= boxes[:, 1]
        np.add(boxes[:, 0], boxes[:, 2] / 2, out=boxes[:, 0], casting="unsafe")
        np.add(boxes[:, 1], boxes[:, 3] / 2, out=boxes[:, 1], casting="unsafe")
    else:
        np.subtract(boxes[:, 0], boxes[:, 2] / 2, out=boxes[:, 0], casting="unsafe")
        np.subtract(boxes[:, 1], boxes[:, 3] / 2, out=boxes[:, 1], casting="unsafe")
        boxes[:, 2] += boxes[:, 0]
        boxes[:, 3] += boxes[:, 1]


def refine_boxes(iou_s, boxes_1, boxes_2, iou_thresh=0.6):
    boxes = []
    used_boxes_1 = set()
    for i, scores in enumerate(iou_s):
        max_idx = np.argmax(scores)
        max_iou = scores[max_idx]
        if max_iou > iou_thresh:
            used_boxes_1.add(max_idx)
            boxes.append(merge_boxes(boxes_2[i], boxes_1[max_idx]))
        else:
            boxes.append(boxes_2[i])

    # for i, box_1 in enumerate(boxes_1):
    #     min_idx = np.argmin(iou_s[:, i])
    #     if iou_s[min_idx, i] == 0:
    #         boxes.append(box_1)

    # boxes = np.array(boxes)
    # convert_boxes(boxes, to_standard=True)
    # boxes = boxes.tolist()
    # indices = nms.nms.boxes(boxes, [1.] * len(boxes), nms_threshold=0.01)
    #
    # refined_boxes = []
    # for idx in indices:
    #     refined_boxes.append(boxes[idx])
    # refined_boxes = np.array(refined_boxes)
    # convert_boxes(refined_boxes, to_standard=False)
    # return refined_boxes
    return np.array(boxes)


def process_stream(stream_path):
    cap = cv2.VideoCapture(stream_path)
    # writer = cv2.VideoWriter('400M_out.avi',
    #                          cv2.VideoWriter_fourcc(*'MJPG'),
    #                          cap.get(cv2.CAP_PROP_FPS),
    #                          (int(cap.get(3)), int(cap.get(4))))

    frames = []
    prev_boxes = np.empty(0)
    sizes = []
    while cap.isOpened():
    #for i in range(0, 597):
        ret, cur = cap.read()
        cur = cv2.resize(cur, (960, 576))
        # ret = True
        #cur = cv2.imread(f"task_d73-2021_06_12_08_04_29-yolo 1.1/obj_train_data/frame_{str(i).zfill(6)}.jpg")
        if not ret:
            break
        orig_frame = np.copy(cur)
        cur = process_frame(cur)
        if len(frames) == PAST_NB_FRAMES:
            frames.pop(0)
        frames.append(cur)
        if len(frames) == PAST_NB_FRAMES:
            diff, boxes = detect_movement(frames[0], cur)

            if prev_boxes.size == 0:
                prev_boxes = boxes
            else:
                if boxes.size != 0:
                    x_iou = calculate_1d_iou(boxes[:, 0], boxes[:, 2], prev_boxes[:, 0], prev_boxes[:, 2])
                    y_iou = calculate_1d_iou(boxes[:, 1], boxes[:, 3], prev_boxes[:, 1], prev_boxes[:, 3])
                    iou_mat = x_iou * y_iou
                    boxes = refine_boxes(iou_mat, prev_boxes, boxes, iou_thresh=0.8)
                    prev_boxes = boxes
                else:
                    boxes = prev_boxes

            frame_copy = orig_frame# cv2.cvtColor(orig_frame, cv2.COLOR_GRAY2BGR)
            # cv2.imwrite('without_box.png', frame_copy)
            box_areas = []
            for i, box in enumerate(boxes):
                centroid_x = int(box[0] + ((box[2] - box[0]) / 2))
                centroid_y = int(box[1] + ((box[3] - box[1]) / 2))
                frame_copy = cv2.rectangle(frame_copy, (box[0], box[1]), (box[2], box[3]), (255, 0, 0), 2)
                # frame_copy = cv2.circle(frame_copy, (centroid_x, centroid_y), 3, (0, 255, 0), -1)
                box_areas.append((box[2] - box[0]) * (box[3] - box[1]))
            sizes.append(box_areas)
            #cv2.imshow('Difference Image', diff)   ####### Commented because we don't need difference
            cv2.namedWindow('HHTI', cv2.WND_PROP_FULLSCREEN)
            cv2.setWindowProperty('HHTI', cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
            cv2.imshow('HHTI', frame_copy)
            # cv2.imwrite('with_box.png', frame_copy)
            # writer.write(frame_copy)
        time.sleep(.05)
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    # cap.release()
    # writer.release()
    cv2.destroyAllWindows()

    # with open("box_sizes.txt", 'w') as f:
    #     f.write(str(sizes))


if __name__ == '__main__':
    # vid_path = '/home/bisag/Documents/movement_detection/data/400M.mp4'
    # vid_path = '/home/bisag/Documents/movement_detection/data/2.5 TON/800M.mp4'
    vid_path = 'D5threemen.avi'
    # vid_path= 'rtsp://root:Admin_123@192.168.13.3:554/Streaming/Channels/102'
    process_stream(0)
