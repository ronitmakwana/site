# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'CameraView.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_CameraView(object):
    def setupUi(self, CameraView):
        CameraView.setObjectName("CameraView")
        CameraView.resize(762, 808)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(CameraView.sizePolicy().hasHeightForWidth())
        CameraView.setSizePolicy(sizePolicy)
        self.verticalLayout = QtWidgets.QVBoxLayout(CameraView)
        self.verticalLayout.setObjectName("verticalLayout")
        self.frameLabel = FrameLabel(CameraView)
        self.frameLabel.setEnabled(True)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Ignored)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.frameLabel.sizePolicy().hasHeightForWidth())
        self.frameLabel.setSizePolicy(sizePolicy)
        self.frameLabel.setMouseTracking(True)
        self.frameLabel.setAutoFillBackground(True)
        self.frameLabel.setFrameShape(QtWidgets.QFrame.Box)
        self.frameLabel.setAlignment(QtCore.Qt.AlignCenter)
        self.frameLabel.setObjectName("frameLabel")
        self.verticalLayout.addWidget(self.frameLabel)
        self.line = QtWidgets.QFrame(CameraView)
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.verticalLayout.addWidget(self.line)
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.frame_preds_label = QtWidgets.QLabel(CameraView)
        self.frame_preds_label.setText("")
        self.frame_preds_label.setObjectName("frame_preds_label")
        self.gridLayout.addWidget(self.frame_preds_label, 2, 0, 1, 1)
        self.pushButton = QtWidgets.QPushButton(CameraView)
        self.pushButton.setObjectName("pushButton")
        self.gridLayout.addWidget(self.pushButton, 2, 1, 1, 1)
        self.gridLayout.setColumnStretch(0, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.verticalLayout.setStretch(0, 1)

        self.retranslateUi(CameraView)
        QtCore.QMetaObject.connectSlotsByName(CameraView)

    def retranslateUi(self, CameraView):
        _translate = QtCore.QCoreApplication.translate
        CameraView.setWindowTitle(_translate("CameraView", "Form"))
        self.pushButton.setText(_translate("CameraView", "Open Log Explorer"))

from FrameLabel import FrameLabel

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    CameraView = QtWidgets.QWidget()
    ui = Ui_CameraView()
    ui.setupUi(CameraView)
    CameraView.show()
    sys.exit(app.exec_())

