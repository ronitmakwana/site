import cv2
import numpy as np

l  =[]
# define a video capture object
vid = cv2.VideoCapture('2.mp4')
def mouse_click(event, x, y,flags, param):
	# to check if left mouse
	# button was clicked
	if event == cv2.EVENT_LBUTTONDOWN:
		
		# font for left click event
            LB = x,y
            l.append(LB)
            print(LB)
          
vidshow = 0
    
while(True):
	
        # Capture the video frame
        # by frame
        ret, frame = vid.read()
        if vidshow == 1:
            mask = np.zeros(frame.shape, dtype=np.uint8)
            cv2.setMouseCallback('frame', mouse_click)
            topLeft = (160, 440)
            bottomRight = (540, 750)
            x, y = topLeft[0], topLeft[1]
            w, h = bottomRight[0] - topLeft[0], bottomRight[1] - topLeft[1]

            # Grab ROI with Numpy slicing and blur
            ROI = frame[y:y+h, x:x+w]
            blur = cv2.GaussianBlur(ROI, (51,51), 0) 

            # Insert ROI back into image
            frame[y:y+h, x:x+w] = blur
            result = cv2.bitwise_and(frame, frame)
            
            # sharpen_kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
            # sharpen = cv2.filter2D(image, -1, sharpen_kernel)

            # cv2.imshow('sharpen', sharpen)
            # cv2.waitKey()
            
            # mask = cv2.circle(mask, (150,200), 305, (255,255,255), -1) 


            # # Mask input image with binary mask
            # result = cv2.bitwise_and(frame, mask)

            # # Color background white
            # result[mask==0] = 255 # Optional

            #Display the resulting frame
            cv2.imshow('frame', result)
        else:
            cv2.imshow('frame', frame)
            vidshow = 1
        # the 'q' button is set as the
        # quitting button you may use any
        # desired button of your choice
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

# After the loop release the cap object
vid.release()
# Destroy all the windows
cv2.destroyAllWindows
# # import csv
# # import pandas as pd

# # d = {'a':'1'}

# # import pandas as pd
# # sample_dict = [
# # {'key1': 1, 'key2': 2, 'key3': 3},
# # {'key1': 4, 'key2': 5, 'key3': 6},
# # {'key1': 7, 'key2': 8, 'key3': 9},
# # ]
# # df = pd.DataFrame.from_dict(sample_dict) 
# # df.to_csv('2.csv',sep=',')


# import csv

# with open('1.csv','r') as f:
#     c = f.readline()
#     print(c)

# import pandas as pd

# df = pd.read_csv('1.csv')
# print(df)

# from re import A


# a = 10
# b =20
# temp  = a
# a = b 
# b = temp
# print(a,b)
