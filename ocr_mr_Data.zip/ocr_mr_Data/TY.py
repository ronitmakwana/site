
import cv2
import numpy as np
import easyocr
from PIL import Image, ImageEnhance

reader = easyocr.Reader(['en'])  #,recog_network='iter_20000'
# Keyword = {1:'Target_No',2:'Esting',3:'Northing',4:'Azimuth',5:'Range'}

Keyword = {'Target_No':1,'Esting':2,'Northing':3,'Azimuth':4,'Range':5}

for i in range(1,5+1):


    im = Image.open('1.png')
    if i == 1:
     left,top,right,bottom = 82,603,172,628
    elif i == 2:
     left,top,right,bottom = 39,652,160,681
    elif i == 3:
     left,top,right,bottom = 175,653,288,678
    elif i == 4:
     left,top,right,bottom = 39,713,168,740
    elif i == 5:
     left,top,right,bottom = 245,714,376,741
    else:
         print('Plase Check The Image') 
    im1 = im.crop((left, top, right, bottom))
    # im1.show()
    im1.save('00.png')
    img = cv2.imread('00.png')
    
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HLS)
    hsv = np.array(hsv, dtype=np.float64)
    hsv[:, :, 1] = hsv[:, :, 1] * 2.6
    hsv[:, :, 1][hsv[:, :, 1] > 255] = 255 # setting values > 255 to 255.
    # scale pixel values up or down for channel 2(Value)
    hsv[:, :, 2] = hsv[:, :, 2] * 2.6
    hsv[:, :, 2][hsv[:, :, 2] > 255] = 255 # setting values > 255 to 255.



    hsv[:, :, 0] = hsv[:, :, 0] + 125
    hsv[:, :, 0][hsv[:, :, 0] > 255] = 255


    hsv[:, :, 2] = hsv[:, :, 2] + 255
    hsv[:, :, 2][hsv[:, :, 2] > 255] = 255


    hsv = np.array(hsv, dtype=np.uint8)
    res = cv2.cvtColor(hsv, cv2.COLOR_HLS2BGR)
    # cv2.imshow('image', res)
    cv2.imwrite('logs/'+str(i)+'.png', res)
    cv2.destroyAllWindows()

for i in range(1,5+1):
    Im_name = []
    Image_val = []
    Image_label = []

    im = Image.open('logs/'+str(i)+'.png')
    enhancer = ImageEnhance.Contrast(im)
    factor = 5 #increase contrast
    im_output = enhancer.enhance(factor)
    im_output.save('00.png')

    im = Image.open('00.png')
    enhancer = ImageEnhance.Brightness(im)
    factor = 1 #increase contrast
    im_output = enhancer.enhance(factor)
    im_output.save('00.png')

    # # im_output.show()
    # originalImage = cv2.imread('00.png')
    # grayImage = cv2.cvtColor(originalImage, cv2.COLOR_BGR2GRAY)
    
    # (thresh, blackAndWhiteImage) = cv2.threshold(grayImage, 127, 255, cv2.THRESH_BINARY)
    # cv2.imwrite('00.png',blackAndWhiteImage)

    results = reader.readtext('00.png',allowlist='0123456789', paragraph=True)

    for k in results:
          if i == 1:
               Keyword['Target_No'] = int(k[1])
          elif i == 2:
               Keyword['Esting'] = int(k[1])
          elif i == 3:
               Keyword['Northing'] = int(k[1])
          elif i == 4:
               Keyword['Azimuth'] = int(k[1])
          elif i == 5:
               Keyword['Range'] = int(k[1])
          else:
               print('No Data Found') 
print('Keyword',Keyword)
        
     
