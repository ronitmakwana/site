# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'BFSR_Simple_GUI.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!
import os
import time
import cv2
import easyocr
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtCore import pyqtSlot, QThread, pyqtSignal
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtWidgets import QWidget
from pyproj import Transformer

from helpers import get_bfsr_location, get_target_location

current_frame = None
os.environ["CUDA_VISIBLE_DEVICES"] = ""


class Thread(QThread):
    changePixmap = pyqtSignal(QImage)

    def run(self):
        cap = cv2.VideoCapture('cdu_screen_video.mp4')
        while True:
            ret, frame = cap.read()
            if ret:
                # https://stackoverflow.com/a/55468544/6622587
                global current_frame
                current_frame = frame
                rgbImage = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                h, w, ch = rgbImage.shape
                bytesPerLine = ch * w
                convertToQtFormat = QImage(rgbImage.data, w, h, bytesPerLine, QImage.Format_RGB888)
                p = convertToQtFormat.scaled(640, 480, QtCore.Qt.KeepAspectRatio)
                self.changePixmap.emit(p)
                time.sleep(1 / 30)


class Ui_MainWindow(QWidget):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(640, 480)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.capture_bfsr_location_button = QtWidgets.QPushButton(self.centralwidget)
        self.capture_bfsr_location_button.setGeometry(QtCore.QRect(88, 20, 181, 25))
        self.capture_bfsr_location_button.setObjectName("pushButton")
        self.capture_target_location_button = QtWidgets.QPushButton(self.centralwidget)
        self.capture_target_location_button.setGeometry(QtCore.QRect(360, 20, 191, 25))
        self.capture_target_location_button.setObjectName("pushButton_2")
        self.cdu_screen_label = QtWidgets.QLabel(self.centralwidget)
        self.cdu_screen_label.setGeometry(QtCore.QRect(20, 60, 601, 411))
        self.cdu_screen_label.setObjectName("graphicsView")

        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        self.capture_bfsr_location_button.clicked.connect(self.capture_bfsr_location_button_listener)
        self.capture_target_location_button.clicked.connect(self.capture_target_location_button_listener)

        self._easyocr = easyocr.Reader(["en"])
        self.transformer = Transformer.from_crs(24379, 4326)

        th = Thread(self)
        th.changePixmap.connect(self.set_image)
        th.start()

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "BFSR"))
        self.capture_bfsr_location_button.setText(_translate("MainWindow", "Capture BFSR Location"))
        self.capture_target_location_button.setText(_translate("MainWindow", "Start Capturing Targets"))

    def capture_bfsr_location_button_listener(self):
        print("pushButton function called")
        global current_frame

        # For image of size 640x480
        roi_box_coords = [[260, 290], [400, 340]]  # Top left, Bottom right (x, y)

        roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]

        get_bfsr_location(roi, self._easyocr, self.transformer)

    def capture_target_location_button_listener(self):
        print("pushButton2 function called")
        global current_frame

        # For image of size 640x480
        roi_box_coords = [[440, 155], [635, 475]]  # Top left, Bottom right (x, y)

        roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]

        get_target_location(roi, self._easyocr, self.transformer)

    @pyqtSlot(QImage)
    def set_image(self, image):
        self.cdu_screen_label.setPixmap(QPixmap.fromImage(image))


if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
