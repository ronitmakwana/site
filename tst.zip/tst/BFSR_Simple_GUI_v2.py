# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'BFSR_Simple_GUI_v2.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!
import os
import sys
import threading
import time
import cv2
import easyocr
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtCore import QThread, pyqtSignal, pyqtSlot
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtWidgets import QWidget
from pyproj import Transformer
from helpers import get_bfsr_location, get_target_location, clear_target_locations
import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets
import pyqtgraph
import SWHear
import warnings
# from test_on_stream import ExampleApp
import faulthandler
import sqlite3

faulthandler.enable()

warnings.filterwarnings("ignore")

class Thread(QThread):
    changePixmap = pyqtSignal(QImage)

    def __init__(self, width, height):
        super().__init__()
        self.width, self.height = width, height

    def run(self):
        # self._stop_event = threading.Event()
        global kill_set_img_th
        cap = cv2.VideoCapture('cdu_screen_video.mp4')
        while not kill_set_img_th:
            ret, frame = cap.read()
            if ret:
                # https://stackoverflow.com/a/55468544/6622587
                global current_frame
                current_frame = np.copy(frame)
                current_frame = cv2.resize(current_frame, (640, 480))
                img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                h, w, ch = img.shape
                bytes_per_line = ch * w
                qt_img = QImage(img.data, w, h, bytes_per_line, QImage.Format_RGB888)
                p = qt_img.scaled(self.width, self.height, QtCore.Qt.IgnoreAspectRatio)
                self.changePixmap.emit(p)
                time.sleep(1 / 30)
            else:
                break
        cap.release()

    # def stop(self):
    #     self._stop_event.set()

'''
def capture_target_location(_easyocr, transformer):
    # For image of size 640x480
    global kill_ocr_thread
    roi_box_coords = [[440, 155], [635, 475]]  # Top left, Bottom right (x, y)
    while not kill_ocr_thread:
        if ocr_on_target_screen_flag:
            roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
            get_target_location(roi, _easyocr, transformer)
            # time.sleep(15)

'''
    # self.grFFT.plotItem.showGrid(True, True, 0.7)
    #     self.grPCM.plotItem.showGrid(True, True, 0.7)
grFFT = 0
grPCM = 0
var = ""
# conn = sqlite3.connect('BFSR_PRED.db')
class Ui_MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        
    def setupUi(self, MainWindow):
        global grFFT
        global grPCM
        MainWindow.setObjectName("MainWindow")

        screen_size = app.primaryScreen().size()
        self.window_width = screen_size.width() - 100
        self.window_height = screen_size.height() - 100

        MainWindow.setFixedSize(self.window_width, self.window_height)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.keyPressEvent = self.keyPressEvent
        self.centralwidget.setObjectName("centralwidget")
        self.capture_bfsr_location_button = QtWidgets.QPushButton(self.centralwidget)
        self.capture_bfsr_location_button.setGeometry(QtCore.QRect(10, 20, 201, 25))
        self.capture_bfsr_location_button.setObjectName("pushButton")
        self.target_capture_button = QtWidgets.QPushButton(self.centralwidget)
        self.target_capture_button.setGeometry(QtCore.QRect(210, 20, 141, 25))
        self.target_capture_button.setObjectName("pushButton_2")
        self.cdu_screen_label = QtWidgets.QLabel(self.centralwidget)
        self.target_type = ""

        vid_width = self.window_width - 20
        vid_height = self.window_height - 80
        self.cdu_screen_label.setGeometry(QtCore.QRect(10, 60,
                                                       vid_width,
                                                       vid_height))
        self.cdu_screen_label.setObjectName("graphicsView")
        self.clear_targets_button = QtWidgets.QPushButton(self.centralwidget)
        self.clear_targets_button.setGeometry(QtCore.QRect(350, 20, 141, 25))
        self.clear_targets_button.setObjectName("pushButton_3")
        self.show_on_map_button = QtWidgets.QPushButton(self.centralwidget)
        self.show_on_map_button.setGeometry(QtCore.QRect(490, 20, 141, 25))
        self.show_on_map_button.setObjectName("pushButton_4")
        self.label1 = QtWidgets.QLabel(self.centralwidget)

        # vid_width = self.window_width - 20
        # vid_height = self.window_height - 80
        self.label1.setGeometry(QtCore.QRect(920, 60, 880, 920))
        self.label1.setStyleSheet("border: 1px solid black;")
        self.label1.setObjectName("graphicsView")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        
        #**********************#
        
        # self.centralwidget = QtWidgets.QWidget(MainWindow)
        # self.centralwidget.setObjectName("centralwidget")
        
        pyqtgraph.setConfigOption('background', 'w') 
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.label1)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.pbLevel = QtWidgets.QProgressBar(self.label1)
        self.pbLevel.setMaximum(1000)
        self.pbLevel.setProperty("value", 123)
        self.pbLevel.setTextVisible(False)
        self.pbLevel.setOrientation(QtCore.Qt.Vertical)
        self.pbLevel.setObjectName("pbLevel")
        self.horizontalLayout.addWidget(self.pbLevel)
        self.frame = QtWidgets.QFrame(self.label1)
        self.frame.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.frame.setFrameShadow(QtWidgets.QFrame.Plain)
        self.frame.setObjectName("frame")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.frame)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label = QtWidgets.QLabel(self.frame)
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        self.grFFT = PlotWidget(self.frame)
        self.grFFT.setObjectName("grFFT")
        self.verticalLayout.addWidget(self.grFFT)
        self.prediction = QtWidgets.QLabel(self.frame)
        font = QtGui.QFont()
        font.setPointSize(20)
        self.prediction.setFont(font)
        self.prediction.setObjectName("prediction")
        self.verticalLayout.addWidget(self.prediction, 0, QtCore.Qt.AlignHCenter)
        self.label_2 = QtWidgets.QLabel(self.frame)
        self.label_2.setObjectName("label_2")
        self.verticalLayout.addWidget(self.label_2)
        self.grPCM = PlotWidget(self.frame)
        self.grPCM.setObjectName("grPCM")
        self.verticalLayout.addWidget(self.grPCM)
        self.horizontalLayout.addWidget(self.frame)
        MainWindow.setCentralWidget(self.centralwidget)
        
        pyqtgraph.setConfigOption('background', 'w')
        
        self.grFFT.plotItem.showGrid(True, True, 0.7)
        self.grPCM.plotItem.showGrid(True, True, 0.7)
        self.maxFFT = 0
        self.maxPCM = 0


        #**********************#
        

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.capture_bfsr_location_button.clicked.connect(self.capture_bfsr_location_button_listener)
        self.target_capture_button.clicked.connect(self.target_capture_button_listener)
        self.clear_targets_button.clicked.connect(self.clear_targets_button_listener)

        self._easyocr = easyocr.Reader(["en"])
        self.transformer = Transformer.from_crs(24379, 4326)

        self.video_display_th = Thread(880, 920)
        self.video_display_th.changePixmap.connect(self.set_image)
        self.video_display_th.setTerminationEnabled(True)
        self.video_display_th.start()
        
        self.ear = SWHear.SWHear(device=7, rate=44100, updatesPerSecond=20)
        self.ear.stream_start()


    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.capture_bfsr_location_button.setText(_translate("MainWindow", "Cap BFSR Loc"))
        self.target_capture_button.setText(_translate("MainWindow", "Cap Tgt Loc"))
        self.clear_targets_button.setText(_translate("MainWindow", "Clear Tgts"))
        self.show_on_map_button.setText(_translate("MainWindow", "Show Map"))
        self.label.setText(_translate("MainWindow", "Frequency Data (FFT):"))
        self.prediction.setText(_translate("MainWindow", "<>"))
        self.label_2.setText(_translate("MainWindow", "Raw Data (PCM):"))


    def update(self):
      
        if not self.ear.data is None and not self.ear.fft is None:
            pcmMax = np.max(np.abs(self.ear.data))
            if pcmMax > self.maxPCM:
                self.maxPCM = pcmMax
                self.grPCM.plotItem.setRange(yRange=[-pcmMax, pcmMax])
            if np.max(self.ear.fft) > self.maxFFT:
                self.maxFFT = np.max(np.abs(self.ear.fft))
                self.grFFT.plotItem.setRange(yRange=[0,self.maxFFT])
                self.grFFT.plotItem.setRange(yRange=[0, 1])
            try:
                self.pbLevel.setValue(1000 * pcmMax / self.maxPCM)
                pass
            except TypeError:
                self.pbLevel.setValue(0)
            self.prediction.setText(self.ear.final_prediction)
            pen = pyqtgraph.mkPen(color='b')
            self.grPCM.plot(self.ear.datax, self.ear.data, pen=pen, clear=True)
            pen = pyqtgraph.mkPen(color='r')
            self.grFFT.plot(self.ear.fftx, self.ear.fft / self.maxFFT, pen=pen, clear=True)
            global var
            var = self.ear.final_prediction[0:14]
            with open('file_audio.txt','w') as f:
                f.write(str(var))
                
      

        QtCore.QTimer.singleShot(1, self.update)  # QUICKLY
    def capture_bfsr_location_button_listener(self):
        print("capture_bfsr_location_button function called")
        global current_frame
        # cv2.imwrite('logs/bfsr_location.png',current_frame)
        # For image of size 640x480
        roi_box_coords = [[260, 290], [400, 340]]  # Top left, Bottom right (x, y)
        roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
        ret = get_bfsr_location(roi, self._easyocr, self.transformer)
        

    def target_capture_button_listener(self):
        print("target_capture_button function called")
        # cv2.imwrite('logs/target_location.png',current_frame)
        
        roi_box_coords = [[440, 155], [635, 475]]  # Top left, Bottom right (x, y)
        roi = current_frame[roi_box_coords[0][1]:roi_box_coords[1][1], roi_box_coords[0][0]:roi_box_coords[1][0]]
        ret = get_target_location(roi,self.target_type, self._easyocr, self.transformer) 

    def clear_targets_button_listener(self):
        print("clear_targets_button function called")
        clear_target_locations()
        

    @pyqtSlot(QImage)
    def set_image(self, image):
        
        self.cdu_screen_label.setPixmap(QPixmap.fromImage(image))
        
    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_1:
            self.target_type = "No sound"
        elif event.key() == QtCore.Qt.Key_2:
            self.target_type = "Heavy vehicle"
        elif event.key() == QtCore.Qt.Key_3:
            self.target_type = "Light vehicle"
        elif event.key() == QtCore.Qt.Key_4:
            self.target_type = "Group of men"
        print(self.target_type)
        
# cursor = conn.cursor()
# command = "CREATE TABLE IF NOT EXISTS PRED(id AUTO INCREMENT PRIMARY KEY,target_name Varchar)"
# cursor.execute(command)
# comm ="INSERT INTO pred (target_name) VALUES ('"+str(var)+"')"
# cursor.execute(comm)
# cursor.close()
# conn.commit()
from pyqtgraph import PlotWidget


if __name__ == "__main__":
    
    # sys.stdout = open('stdout.txt', 'w')
    # sys.stderr = open('stderr.txt', 'w')

    os.environ["CUDA_VISIBLE_DEVICES"] = "0"

    kill_set_img_th = False
    current_frame = True

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    ui.update()
    MainWindow.show()
    
    # form = ExampleApp()
    # form.show()
    # form.update() 
    exit_status = app.exec_()
    kill_set_img_th = True
    # form = ExampleApp()
    # form.show()
    # form.update()  # start with something
    # app.exec_()
    # print("DONE")

    # ui.video_display_th.stop()

    # sys.stdout.close()
    # sys.stderr.close()
    sys.exit(exit_status)
