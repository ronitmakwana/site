"""
this is a stripped down version of the SWHear class.
It's designed to hold only a single audio sample in memory.
check my githib for a more complete version:
    http://github.com/swharden
"""
from collections import Counter
import pyaudio
import time
import numpy as np
import threading
import torch
from matplotlib import pyplot as plt
from training.model import AudioCNNClassifier, infer
from torchvision.transforms import Normalize

device = 'cpu'
desired_sr = 16000
max_audio_duration_ms = 5000

checkpoint = torch.load("training/models/bfsr_cnn_librosa_dharanghdhara_lt_hv.pt", map_location=device)
#checkpoint = torch.load("training/models/bfsr_cnn_librosa_chiloda_v3.pt", map_location=device)
cnn = AudioCNNClassifier()
cnn.load_state_dict(checkpoint["model_state_dict"])
#print(cnn)


def getFFT(data, rate):
    """Given some data and rate, returns FFTfreq and FFT (half)."""
    data = data * np.hamming(len(data))
    fft = np.fft.fft(data)
    fft = np.abs(fft)
    # fft=10*np.log10(fft)
    freq = np.fft.fftfreq(len(fft), 1.0 / rate)
    return freq[:int(len(freq) / 2)], fft[:int(len(fft) / 2)]


class SWHear:
    """
    The SWHear class is provides access to continuously recorded
    (and mathematically processed) microphone data.
    
    Arguments:
        
        device - the number of the sound card input to use. Leave blank
        to automatically detect one.
        
        rate - sample rate to use. Defaults to something supported.
        
        updatesPerSecond - how fast to record new data. Note that smaller
        numbers allow more data to be accessed and therefore high
        frequencies to be analyzed if using a FFT later
    """

    def __init__(self, device=None, rate=None, updatesPerSecond=10):
        self.p = pyaudio.PyAudio()
        self.updatesPerSecond = updatesPerSecond
        self.chunksRead = 0
        self.device = device
        self.rate = rate
        self.chunk = self.rate  # gets replaced automatically
        self.buffer = None
        self.inference_window_size_secs = 5 # Change depending on the model
        self.preds = []
        self.probs = []
        self.keep_preds_size = (12 * self.rate) / self.chunk
        self.final_prediction = ''
        #class_to_idx = {"heavy vehicle": 0, "light vehicle": 1}
        #class_to_idx = {"Heavy Vehicle": 0, "crawling man": 1, "group of men": 2, "single walking man": 3}
        #class_to_idx = {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1, "GROUP OF MEN": 2}
        class_to_idx = {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1}
        #class_to_idx = {"VEHICLE": 0, "GROUP OF MEN": 1}
        self.idx_to_class = {v: k for k, v in class_to_idx.items()}
        self.frames = []

    ### SYSTEM TESTS

    def valid_low_rate(self, device):
        """set the rate to the lowest supported audio rate."""
        if self.valid_test(device):
            return self.rate
        else:
            print("SOMETHING'S WRONG! I can't figure out how to use DEV", device)
            return None

    def valid_test(self, device):
        """given a device ID and a rate, return TRUE/False if it's valid."""
        try:
            self.info = self.p.get_device_info_by_index(device)
            if not self.info["maxInputChannels"] > 0:
                return False
            stream = self.p.open(format=pyaudio.paInt16, channels=1,
                                 input_device_index=self.device, frames_per_buffer=self.chunk,
                                 rate=int(self.info["defaultSampleRate"]), input=True)
            stream.close()
            return True
        except:
            return False

    def valid_input_devices(self):
        """
        See which devices can be opened for microphone input.
        call this when no PyAudio object is loaded.
        """
        mics = []
        for device in range(self.p.get_device_count()):
            if self.valid_test(device):
                mics.append(device)
        if len(mics) == 0:
            print("no microphone devices found!")
        else:
            print("found %d microphone devices: %s" % (len(mics), mics))
        return mics

    ### SETUP AND SHUTDOWN

    def initiate(self):
        """run this after changing settings (like rate) before recording"""
        if self.device is None:
            self.device = self.valid_input_devices()[0]  # pick the first one
        if self.rate is None:
            self.rate = self.valid_low_rate(self.device)
        self.chunk = int(self.rate / self.updatesPerSecond)  # hold one tenth of a second in memory
        if not self.valid_test(self.device):
            print("guessing a valid microphone device/rate...")
            self.device = self.valid_input_devices()[0]  # pick the first one
            self.rate = self.valid_low_rate(self.device)
        self.datax = np.arange(self.chunk) / float(self.rate)
        self.keep_preds_size = (12 * self.rate) / self.chunk
        msg = 'recording from "%s" ' % self.info["name"]
        msg += '(device %d) ' % self.device
        msg += 'at %d Hz' % self.rate
        print(msg)

    def close(self):
        """gently detach from things."""
        print(" -- sending stream termination command...")
        self.keepRecording = False  # the threads should self-close
        while self.t.is_alive():  # wait for all threads to close
            time.sleep(.1)
        self.stream.stop_stream()
        self.p.terminate()

    ### STREAM HANDLING

    def stream_readchunk(self):
        """reads some audio and re-launches itself"""
        '''
        try:
            self.data = np.frombuffer(self.stream.read(self.chunk), dtype=np.int16)
            if self.buffer is not None:
                self.buffer = np.hstack([self.buffer, self.data])
            else:
                self.buffer = self.data
            print(self.buffer.shape)
            if self.buffer.shape[0] == (self.rate * (self.inference_window_size_secs + 1)):
                self.buffer = np.delete(self.buffer, list(range(self.rate)))
            if self.buffer.shape[0] == (self.rate * self.inference_window_size_secs):
                input_tensor = torch.from_numpy(self.buffer).unsqueeze(0)
                print(input_tensor.shape)
                prediction = infer(input_tensor, self.rate)
                print(f"Prediction: {prediction}")
                if self.preds == self.keep_preds_size:
                    self.preds = self.preds.pop(0)
                self.preds.append(prediction)

            self.fftx, self.fft = getFFT(self.data, self.rate)

        except Exception as E:
            print(" -- exception! terminating...")
            print(E, "\n" * 5)
            self.keepRecording = False
        '''
        local_chunk = self.stream.read(self.chunk, exception_on_overflow=False)
        self.data = np.frombuffer(local_chunk, dtype=np.int16).astype(np.float32, order='C') / 32768.0
        self.frames.append(local_chunk)
        if self.buffer is not None:
            self.buffer = np.hstack([self.buffer, self.data])
        else:
            self.buffer = self.data
        if self.buffer.shape[0] > (self.rate * self.inference_window_size_secs):
            self.buffer = self.buffer[-(self.rate * self.inference_window_size_secs):]
        # plt.hist(self.data, bins=1000)
        # plt.show()
        nb_recent_samples = int(1 * self.rate)
        # if (np.logical_and(-.003 <= self.buffer[-nb_recent_samples:],
        #                    self.buffer[-nb_recent_samples:] <= .003).sum() / self.buffer[-nb_recent_samples:].shape[
        #         0]) > .8:
        if np.max(self.buffer[-nb_recent_samples:]) - np.min(self.buffer[-nb_recent_samples:]) <= 0.002:
            self.final_prediction = 'No sound or Noise'
            self.preds.clear()
            self.probs.clear()
        # TODO: detect noise function
        else:
            if self.buffer.shape[0] == (self.rate * self.inference_window_size_secs):
                # input_tensor = torch.from_numpy(self.buffer).unsqueeze(0).type(torch.float32)
                input_audio = np.copy(self.buffer)
                prob, pred_id = infer(classifier=cnn,
                                      data=input_audio,
                                      input_sr=self.rate,
                                      desired_sr=desired_sr,
                                      max_audio_duration_ms=max_audio_duration_ms,
                                      normalize=Normalize(mean=[51.55220031738281], std=[20.79323387145996]),
                                      device=device)
                if len(self.preds) == self.keep_preds_size:
                    del self.preds[0]
                    del self.probs[0]

                # print(self.preds)
                self.preds.append(pred_id)
                self.probs.append(prob)

                frqs = Counter(self.preds)
                final_pred_id = frqs.most_common(1)[0][0]
                cnt = 0
                avg = 0
                for i, prob in enumerate(self.probs):
                    if self.preds[i] == final_pred_id:
                        avg += self.probs[i]
                        cnt += 1
                avg_prob = (avg / cnt) * 100

                self.final_prediction = f"{self.idx_to_class[pred_id]} : {int(prob*100)}%"
                self.buffer = None

        self.fftx, self.fft = getFFT(self.data, self.rate)
        if self.keepRecording:
            self.stream_thread_new()
        else:
            self.stream.close()
            self.p.terminate()
            print(" -- stream STOPPED")
        self.chunksRead += 1

    def stream_thread_new(self):
        self.t = threading.Thread(target=self.stream_readchunk)
        self.t.start()

    def stream_start(self):
        """adds data to self.data until termination signal"""
        self.initiate()
        print(" -- starting stream")
        self.keepRecording = True  # set this to False later to terminate stream
        self.data = None  # will fill up with threaded recording data
        self.fft = None
        self.dataFiltered = None  # same
        self.stream = self.p.open(format=pyaudio.paInt16, channels=1, input_device_index=self.device,
                                  rate=self.rate, input=True, frames_per_buffer=self.chunk)
        self.stream_thread_new()


if __name__ == "__main__":
    ear = SWHear(updatesPerSecond=10)  # optinoally set sample rate here
    ear.stream_start()  # goes forever
    lastRead = ear.chunksRead
    while True:
        while lastRead == ear.chunksRead:
            time.sleep(.01)
        print(ear.chunksRead, len(ear.data))
        lastRead = ear.chunksRead
    print("DONE")
