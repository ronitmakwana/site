import json
import easyocr
from PIL import Image, ImageEnhance
from datetime import datetime
start_time = datetime.now()

      
# Driver Code
r1, r2 = 1, 50
list = list(range(r1, r2+1))
reader = easyocr.Reader(['en'])   


for i in list:
     img = ("ImNum/"+str(i)+".bmp")
     
     # # get width and height
     # width = img.width
     # height = img.height


     # image = Image.open("ImNum/"+str(i)+".jpg")
     # # print(f"Original size : {image.size}") # 5464x3640

     # sunset_resized = image.resize((width*5, height*5))
     # sunset_resized.save('00.jpg')

     im = Image.open("ImNum/"+str(i)+".bmp")
     enhancer = ImageEnhance.Contrast(im)


     factor = 1.0 #increase contrast
     im_output = enhancer.enhance(factor)
     im_output.save('00.bmp')

     # im = Image.open('00.jpg')
     # enhancer = ImageEnhance.Brightness(im)


     # factor = 1.0 #increase contrast
     # im_output = enhancer.enhance(factor)
     # im_output.save('00.jpg')



     # im_output.show()

     results = reader.readtext('00.bmp',paragraph=True)
     # print(results)

     for j in results: 
          print('ImNum/'+str(i)+'.bmp : ',j[1])
          
          

end_time = datetime.now()
print('Duration: {}'.format(end_time - start_time))

