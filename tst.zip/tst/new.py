from PyQt5 import QtGui, QtCore
import sys
import numpy as np
import sys
from test_on_stream import ExampleApp


sys.stdout = open('stdout.txt', 'w')
sys.stderr = open('stderr.txt', 'w')
app = QtGui.QApplication(sys.argv)
form = ExampleApp()
form.show()
form.update()  # start with something
app.exec_()
print("DONE")
'''
wf = wave.open("data.wav", 'wb')
wf.setnchannels(1)
wf.setsampwidth(form.ear.p.get_sample_size(pyaudio.paInt16))
wf.setframerate(44100)
wf.writeframes(b''.join(form.ear.frames))
wf.close()
'''
form.ear.keepRecording = False
# cleanup_stop_thread()

sys.stdout.close()
sys.stderr.close()

