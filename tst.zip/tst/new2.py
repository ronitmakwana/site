# import subprocess

# subprocess.run("python3 /home/bisag/Yogesh/BFSR_GUI_SR _new/new.py & python3 /home/bisag/Yogesh/audio/756eaf2f0c62549f1b55460cce85643e-5e37d836b41f03cae8f794c7ce96fd9ce070c446/bfsr_chiloda/new.py", shell=True)

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (QWidget, QHBoxLayout, QFrame,
                             QSplitter, QApplication)
import sys
 
class Example(QWidget):
 
    def __init__(self):
        super().__init__()
 
        self.initUI()
 
    def initUI(self):
 
        hbox = QHBoxLayout(self)
 
        topleft = QFrame(self)
        topleft.setFrameShape(QFrame.StyledPanel)
 
        topright = QFrame(self)

        topright.setFrameShape(QFrame.StyledPanel)
 
        bottom = QFrame(self)
        bottom.setFrameShape(QFrame.StyledPanel)
 
        splitter1 = QSplitter(Qt.Horizontal)
        splitter1.addWidget(topleft)
        splitter1.addWidget(topright)
 
        splitter2 = QSplitter(Qt.Vertical)
        splitter2.addWidget(splitter1)
        splitter2.addWidget(bottom)
 
        hbox.addWidget(splitter2)
        self.setLayout(hbox)
 
        self.setGeometry(300, 300, 450, 400)
        self.setWindowTitle('QSplitter')
        self.show()
 
 
def main():
    app = QApplication(sys.argv)
    ex = Example()
    sys.exit(app.exec_())
 
 
if __name__ == '__main__':
    main()