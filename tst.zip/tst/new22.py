# import os
# import sys
# from PyQt5 import QtCore, QtWidgets
# from PyQt5.QtCore import QThread, pyqtSignal, pyqtSlot
# from BFSR_Simple_GUI_v2 import Ui_MainWindow
# #if __name__ == "__main__":
    
#     # sys.stdout = open('stdout.txt', 'w')
#     # sys.stderr = open('stderr.txt', 'w')

# os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# kill_set_img_th = False
# current_frame = True

# app = QtWidgets.QApplication(sys.argv)
# MainWindow = QtWidgets.QMainWindow()
# ui = Ui_MainWindow()
# ui.setupUi(MainWindow)
# MainWindow.show()
# exit_status = app.exec_()
# kill_set_img_th = True
# # ui.video_display_th.stop()

# # sys.stdout.close()
# # sys.stderr.close()
# sys.exit(exit_status)


list_of_target=[]
dict_of_target={'target':[]}
with open('file_audio.txt','r') as fs:
    target = fs.read()
    list_of_target.append(target)
    print(list_of_target)
    target_type = list_of_target[-1]
    # print(target_type)
