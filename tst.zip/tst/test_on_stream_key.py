from PyQt5 import QtGui, QtCore
import sys
import ui_main
import numpy as np
import pyqtgraph
import SWHear
import warnings
import pyaudio
import wave
import random
import sys
# import faulthandler

# faulthandler.enable()

warnings.filterwarnings("ignore")


class ExampleApp(QtGui.QMainWindow, ui_main.Ui_MainWindow):
    def __init__(self, parent=None):
        pyqtgraph.setConfigOption('background', 'w')  # before loading widget
        super(ExampleApp, self).__init__(parent)
        self.setupUi(self)
        self.grFFT.plotItem.showGrid(True, True, 0.7)
        self.grPCM.plotItem.showGrid(True, True, 0.7)
        self.maxFFT = 0
        self.maxPCM = 0
        self.ear = SWHear.SWHear(device=24, rate=44100, updatesPerSecond=20)
        self.ear.stream_start()
    def update(self):
        if not self.ear.data is None and not self.ear.fft is None:
            pcmMax = np.max(np.abs(self.ear.data))
            if pcmMax > self.maxPCM:
                self.maxPCM = pcmMax
                self.grPCM.plotItem.setRange(yRange=[-pcmMax, pcmMax])
            if np.max(self.ear.fft) > self.maxFFT:
                self.maxFFT = np.max(np.abs(self.ear.fft))
                # self.grFFT.plotItem.setRange(yRange=[0,self.maxFFT])
                self.grFFT.plotItem.setRange(yRange=[0, 1])
            try:
                self.pbLevel.setValue(1000 * pcmMax / self.maxPCM)
            except TypeError:
                self.pbLevel.setValue(0)
            # self.prediction.setText(self.ear.final_prediction)
            pen = pyqtgraph.mkPen(color='b')
            self.grPCM.plot(self.ear.datax, self.ear.data, pen=pen, clear=True)
            pen = pyqtgraph.mkPen(color='r')
            self.grFFT.plot(self.ear.fftx, self.ear.fft / self.maxFFT, pen=pen, clear=True)
        QtCore.QTimer.singleShot(1, self.update)  # QUICKLY repeat

    def keyPressEvent(self, event):
        pred = self.prediction.text()
        if ':' in pred:
            class_name, prob = pred.split(':')
        if event.key() == QtCore.Qt.Key_1:
            self.prediction.setText(f"No sound")
        elif event.key() == QtCore.Qt.Key_2:
            self.prediction.setText(f"Heavy vehicle : {random.randint(50, 90)}%")            
        elif event.key() == QtCore.Qt.Key_3:
            self.prediction.setText(f"Light vehicle : {random.randint(50, 90)}%")
        elif event.key() == QtCore.Qt.Key_4:
            self.prediction.setText(f"Group of men : {random.randint(50, 90)}%")


if __name__ == "__main__":

    sys.stdout = open('stdout.txt', 'w')
    sys.stderr = open('stderr.txt', 'w')
    app = QtGui.QApplication(sys.argv)
    form = ExampleApp()
    form.show()
    form.update()  # start with something
    app.exec_()
    print("DONE")
    '''
    wf = wave.open("data.wav", 'wb')
    wf.setnchannels(1)
    wf.setsampwidth(form.ear.p.get_sample_size(pyaudio.paInt16))
    wf.setframerate(44100)
    wf.writeframes(b''.join(form.ear.frames))
    wf.close()
    '''
    form.ear.keepRecording = False
    # cleanup_stop_thread()

    sys.stdout.close()
    sys.stderr.close()
