import datetime
import os
import librosa
import pandas as pd
from typing import Tuple, List, Dict, Union
import numpy as np
import torch
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset
from torchvision.transforms import Normalize
import pickle
import matplotlib.pyplot as plt
import soundfile as sf
import warnings


def get_data_and_labels(annotation_df_path: str, data_dir_path: str) -> Tuple[List[str], List[int], Dict[int, str]]:
    assert os.path.isfile(annotation_df_path)
    assert os.path.isdir(data_dir_path)
    
    annotation_df = pd.read_csv(annotation_df_path)

    class_to_idx = {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1, "GROUP OF MEN": 2}
    id_to_class = {v: k for k, v in class_to_idx.items()}

    annotation_df['FILEPATH'] = annotation_df['FILEPATH'].apply(lambda rel_path: os.path.join(data_dir_path, rel_path))
    annotation_df['TARGET'] = annotation_df['TARGET'].apply(lambda class_name: class_to_idx[class_name])
    
    file_paths = annotation_df['FILEPATH'].tolist()
    labels = annotation_df['TARGET'].tolist()
    
    
    return file_paths, labels, id_to_class


def filter_audio_dataset(filepaths: List[str], labels: List[int], desired_sr: int, max_audio_duration_ms: int) -> Tuple[
    List[str], List[int]]:
    assert len(filepaths) == len(labels)
    filepaths_filtered = []
    labels_filtered = []
    print("Filtering the dataset...")
    for i in range(len(filepaths)):
        audio, sr = librosa.load(filepaths[i], sr=None)
        try:
            BFSRAudio.preprocess(audio=audio,
                                 sr=sr,
                                 desired_sr=desired_sr,
                                 max_audio_duration_ms=max_audio_duration_ms)
            filepaths_filtered.append(filepaths[i])
            labels_filtered.append(labels[i])
        except:
            print(filepaths[i])
    return filepaths_filtered, labels_filtered


class BFSRAudio(Dataset):
    def __init__(self,
                 file_paths: List[str],
                 labels: List[int],
                 idx_to_class: Dict[int, str],
                 mean: Union[List[float], None],
                 std: Union[List[float], None],
                 desired_sr: int = 16000,
                 max_audio_duration_ms: int = 5000,
                 mask_augment_params: dict = None):
        self.file_paths = file_paths
        self.labels = labels
        self.idx_to_class = idx_to_class
        self.desired_sr = desired_sr
        self.max_audio_duration_ms = max_audio_duration_ms
        self.mean = mean
        self.std = std
        self.mask_augment_params = mask_augment_params
        self.class_weights = self.compute_class_weights()

        if self.mean is None and self.std is None:
            self.mean, self.std = self.calculate_mean_and_dev()

        self.normalize = Normalize(mean=self.mean, std=self.std)

    def compute_class_weights(self):
        (_, nb_samples_per_class) = np.unique(self.labels, return_counts=True)
        return list(map(lambda frq: len(self.labels) / frq, nb_samples_per_class))

    def __len__(self):
        return len(self.file_paths)

    @staticmethod
    def loudness_normalize(audio: np.ndarray, rms_linear_level=1e-1):
        a = np.sqrt((audio.shape[0] * (rms_linear_level ** 2)) / np.sum(audio ** 2))
        return audio * a

    def calculate_mean_and_dev(self):
        print('calculating normalization params')
        data = []
        for i in range(len(self.file_paths)):
            audio, sr = librosa.load(self.file_paths[i], sr=None)

            transformed_audio = self.preprocess(audio=audio,
                                                sr=sr,
                                                desired_sr=self.desired_sr,
                                                max_audio_duration_ms=self.max_audio_duration_ms)

            data.append(transformed_audio.unsqueeze(0))
        data = torch.cat(data)

        mean = []
        std = []
        nb_channels = data.size(1)
        for i in range(nb_channels):
            mean.append(torch.mean(data[:, i, :, :]).item())
            std.append(torch.std(data[:, i, :, :]).item())

        print('Complete')
        print(f"mean: {mean}, std: {std}")
        return mean, std

    # @staticmethod
    # def pad_trunc(audio, sr, max_audio_duration_ms):
    #     sig_len = audio.shape[0]
    #     max_len = sr // 1000 * max_audio_duration_ms

    #     if sig_len > max_len:
    #         audio = audio[:max_len]
    #     elif sig_len < max_len:
    #         pad_begin_len = np.random.randint(0, max_len - sig_len)
    #         pad_end_len = max_len - sig_len - pad_begin_len

    #         pad_begin = np.zeros(pad_begin_len)
    #         pad_end = np.zeros(pad_end_len)

    #         audio = np.hstack([pad_begin, audio, pad_end])

    #     return audio

    @staticmethod
    def pad_trunc(audio, sr, max_audio_duration_ms):
        sig_len = audio.shape[0]
        max_len = int(sr * (max_audio_duration_ms / 1000))

        if sig_len > max_len:
            rem = sig_len - max_len
            start = rem // 2
            audio = audio[start: start + max_len]
        elif sig_len < max_len:
            rep = (max_len // sig_len)
            audio_rep = np.tile(audio, rep)
            rem = max_len - (rep * sig_len)
            audio = np.concatenate((audio_rep, audio[:rem]))

        return audio

    @staticmethod
    def mask_augment(spectrogram: torch.Tensor, params: dict):
        max_mask_pct = params['max_mask_pct'] if 'max_mask_pct' in params else 0.1
        nb_freq_masks = int(params['nb_freq_masks']) if 'nb_freq_masks' in params else int(1)
        nb_time_masks = int(params['nb_time_masks']) if 'nb_time_masks' in params else int(1)
        mask_value = params['mask_value'] if 'mask_value' in params else spectrogram.mean()

        _, n_mels, n_steps = spectrogram.shape

        freq_mask_param = int(max_mask_pct * n_mels)
        for _ in range(nb_freq_masks):
            mask_len = np.random.randint(1, freq_mask_param + 1)
            start = np.random.randint(0, n_mels - mask_len + 1)
            end = start + mask_len
            spectrogram[:, start:end, :] = mask_value

        time_mask_param = int(max_mask_pct * n_steps)
        for _ in range(nb_time_masks):
            mask_len = np.random.randint(1, time_mask_param + 1)
            start = np.random.randint(0, n_steps - mask_len + 1)
            end = start + mask_len
            spectrogram[:, :, start:end] = mask_value

        return spectrogram

    @staticmethod
    def preprocess(audio: np.ndarray,
                   sr: int,
                   desired_sr: int,
                   max_audio_duration_ms: int,
                #    n_fft: int = 1024,
                #    win_length: int = 1024,
                #    hop_length: int = 1024 // 2,
                #    n_mels: int = 64,
                    n_fft: int = 128,
                    win_length: int = 128,
                    hop_length: int = 128 // 2,
                    n_mels: int = 128,
                   plot_waveform: bool = False) -> torch.Tensor:
        audio = librosa.to_mono(audio)
        audio = librosa.resample(audio, sr, desired_sr)
        audio = BFSRAudio.pad_trunc(audio, desired_sr, max_audio_duration_ms)
        # audio = BFSRAudio.loudness_normalize(audio)

        # fn = f'{datetime.datetime.now()}_infer.wav'
        # sf.write(fn, audio, desired_sr, subtype='PCM_24')
        audio = librosa.feature.melspectrogram(audio,
                                               sr=desired_sr,
                                               n_fft=n_fft,
                                               win_length=win_length,
                                               hop_length=hop_length,
                                               n_mels=n_mels,
                                               pad_mode='reflect',
                                               center=True,
                                               power=2,
                                               htk=True,
                                               norm='slaney')
        audio = librosa.amplitude_to_db(audio, top_db=80, ref=np.min)
        # plt.imshow(audio)
        # plt.savefig(fn.replace('.wav', '.png'))

        if plot_waveform:
            plt.imshow(audio)
            plt.show()
        transformed_audio = torch.from_numpy(audio).unsqueeze(0)
        return transformed_audio

    def __getitem__(self, idx):
        audio, sr = librosa.load(self.file_paths[idx], sr=None)
        label = self.labels[idx]

        spectrogram = self.preprocess(audio=audio,
                                      sr=sr,
                                      desired_sr=self.desired_sr,
                                      max_audio_duration_ms=self.max_audio_duration_ms)

        if self.mask_augment_params is not None:
            self.mask_augment_params['mask_value'] = self.mean[0]
            spectrogram = BFSRAudio.mask_augment(spectrogram, self.mask_augment_params)
        spectrogram = self.normalize(spectrogram)
        if spectrogram.isnan().any().item():
            print(self.file_paths[idx])

        # plt.imshow(spectrogram.permute(1, 2, 0).numpy())
        # plt.show()
        return spectrogram.float(), label


def get_datasets(meta_path: str, data_dir_path: str, desired_sr: int, max_audio_duration_ms: int) -> Tuple[
    BFSRAudio, BFSRAudio, BFSRAudio]:
    # X, y, idx_to_class = get_data_and_labels(meta_path, data_dir_path)
    # X, y = filter_audio_dataset(X, y, desired_sr, max_audio_duration_ms)

    # pickle.dump(X, open('data_X.pkl', 'wb'))
    # pickle.dump(y, open('data_y.pkl', 'wb'))

    # print(len(X), len(y))

    # exit()

    # class_to_idx = {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1, "GROUP OF MEN": 2} # (v1 & v2)
    class_to_idx = {"VEHICLE": 0, "GROUP OF MEN": 1} # v3
    
    idx_to_class = {v: k for k, v in class_to_idx.items()}


    X = pickle.load(open('data_X.pkl', 'rb'))
    y = pickle.load(open('data_y_v3.pkl', 'rb'))

    print(len(X), len(y))

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=1, stratify=y)
    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.1, random_state=1,
                                                      stratify=y_train)

    # For {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1, "GROUP OF MEN": 2}
    # mean: [78.74880732380272], std: [26.040366700751193] (v1)


    # mean: [51.55220031738281], std: [20.79323387145996] (v2 & v3)
    # when all random seeds are 1
    train_dataset = BFSRAudio(file_paths=X_train,
                              labels=y_train,
                              idx_to_class=idx_to_class,
                              mean=[51.55220031738281],
                              std=[20.79323387145996],
                            #   mean=None,
                            #   std=None,
                              desired_sr=desired_sr,
                              max_audio_duration_ms=max_audio_duration_ms,
                            #   mask_augment_params={
                            #       'max_mask_pct': 1 / 10,
                            #       'nb_time_masks': 2
                            #   }
                            )

    val_dataset = BFSRAudio(file_paths=X_val,
                            labels=y_val,
                            idx_to_class=idx_to_class,
                            mean=[51.55220031738281],
                            std=[20.79323387145996],
                            desired_sr=desired_sr,
                            max_audio_duration_ms=max_audio_duration_ms)

    test_dataset = BFSRAudio(file_paths=X_test,
                             labels=y_test,
                             idx_to_class=idx_to_class,
                             mean=[51.55220031738281],
                             std=[20.79323387145996],
                             desired_sr=desired_sr,
                             max_audio_duration_ms=max_audio_duration_ms)

    return train_dataset, val_dataset, test_dataset


if __name__ == '__main__':
    warnings.filterwarnings('ignore')
    train, val, test = get_datasets(meta_path="/home/user/Documents/bfsr/phase_2/annotations.csv",
                                    data_dir_path="/home/user/Documents/bfsr/phase_2",
                                    desired_sr=16000,
                                    max_audio_duration_ms=5000)

    for i in range(len(train)):
        x, _ = train[i]
        print(x.shape)
        break
