from math import trunc
import librosa
import pickle
import cv2
import numpy as np
import pathlib

def pad_truncate(audio, sr, max_duration_ms):
    sig_len = audio.shape[0]
    max_len = int(sr * (max_duration_ms / 1000))

    if sig_len > max_len:
        rem = sig_len - max_len
        start = rem // 2
        audio = audio[start: start + max_len]
    elif sig_len < max_len:
        rep = (max_len // sig_len)
        audio_rep = np.tile(audio, rep)
        rem = max_len - (rep * sig_len)
        audio = np.concatenate((audio_rep, audio[:rem]))

    return audio

def preprocess(audio: np.ndarray,
                sr: int,
                desired_sr: int,
                max_audio_duration_ms: int,
                n_fft: int = 128,
                win_length: int = 128,
                hop_length: int = 128 // 2,
                n_mels: int = 128,
                plot_waveform: bool = False) -> np.ndarray:

        audio = librosa.to_mono(audio)
        audio = librosa.resample(audio, sr, desired_sr)
        audio = pad_truncate(audio, desired_sr, max_audio_duration_ms)
        # audio = BFSRAudio.loudness_normalize(audio)
        audio = librosa.feature.melspectrogram(audio,
                                               sr=desired_sr,
                                               n_fft=n_fft,
                                               win_length=win_length,
                                               hop_length=hop_length,
                                               n_mels=n_mels,
                                               pad_mode='reflect',
                                               center=True,
                                               power=2,
                                               htk=True,
                                               norm='slaney')
        audio = librosa.amplitude_to_db(audio, top_db=80, ref=np.min)
        return audio


def get_fn(fp):
    path = pathlib.Path(fp)
    path = str(pathlib.Path(*path.parts[-3:])).replace(' ', '-')
    path = path.replace('/', '_').split('.')[0]
    return path

def save_spectrogram(fp, save_path) -> bool:
    audio, sr = librosa.load(fp, sr=None)
    try:
        less_five = (audio.shape[0] / sr) < 5
        if less_five:
            save_path = save_path.replace('.png', '_lt_five.png')

        spectrogram = preprocess(audio=audio,
                                sr=sr,
                                desired_sr=16000,
                                max_audio_duration_ms=5000)
        spectrogram = (255 / (np.max(spectrogram) - np.min(spectrogram))) * (spectrogram - np.min(spectrogram))
        
        # spectrogram = cv2.resize(spectrogram, (640, 260))
        print(spectrogram.shape)
        
        spectrogram = spectrogram.astype(np.uint8)
        heatmap = cv2.applyColorMap(spectrogram, cv2.COLORMAP_SUMMER)

        cv2.imwrite(save_path, heatmap)
        return True
    except Exception as exp:
        print(exp)
        return False

def main():
    X = pickle.load(open('data_X.pkl', 'rb'))
    y = pickle.load(open('data_y.pkl', 'rb'))

    class_to_idx = {"HEAVY VEHICLE": 0, "LIGHT VEHICLE": 1, "GROUP OF MEN": 2}
    idx_to_class = {v: k for k, v in class_to_idx.items()}


    counts = [0, 0, 0]
    cnt = 0
    for fp, class_id in zip(X, y):
        fn = get_fn(fp)

        class_name = idx_to_class[class_id].lower().replace(" ", "_")
        
        save_path = f"spectrograms/{fn}_{class_name}_{counts[class_id]}.png"
        if save_spectrogram(fp, save_path):
            counts[class_id] += 1
            cnt += 1
            print(cnt)
    


if __name__ == '__main__':
    main()