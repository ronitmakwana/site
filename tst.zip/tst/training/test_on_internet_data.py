import time
import librosa
import torch
from model import AudioCNNClassifier, infer
from torchvision.transforms import Normalize


desired_sr = 16000
max_audio_duration_ms = 10000
device = 'cpu'  # 'cuda' if torch.cuda.is_available() else 'cpu'

class_to_idx = {"2.5 ton": 0, "crawling man": 1, "group of men": 2, "single walking man": 3}
idx_to_class = {v: k for k, v in class_to_idx.items()}

checkpoint = torch.load("models/bfsr_cnn_librosa_v1.pt", map_location=device)
print(f"Epoch: {checkpoint['epoch']}")
print(f"Val. loss after training: {checkpoint['val_loss']}")

cnn = AudioCNNClassifier()
cnn.load_state_dict(checkpoint["model_state_dict"])

# audio, sr = torchaudio.load("/home/bisag/Documents/radar_audio_demo/audio_samples/jack_hammer_sound.wav")
# audio, sr = torchaudio.load("/home/bisag/Documents/radar_audio_demo/audio_samples/police_siren.mp3")
# audio, sr = torchaudio.load("/home/bisag/Documents/radar_audio_demo/audio_samples/drilling.mp3")
# audio, sr = torchaudio.load("/home/bisag/Documents/radar_audio_demo/audio_samples/children_playing.wav")
# audio, sr = torchaudio.load("/home/bisag/Documents/radar_audio_demo/audio_samples/dog_bark.wav")
# audio, sr = torchaudio.load("/home/bisag/Documents/radar_audio_demo/audio_samples/car_horn.wav")
# audio, sr = torchaudio.load("/home/bisag/Documents/radar_audio_demo/audio_samples/gun_shot.mp3")
# audio, sr = torchaudio.load("/home/bisag/Documents/radar_audio_demo/audio_samples/siren_record.wav")
# audio, sr = torchaudio.load("/home/bisag/Documents/radar_audio_demo/audio_samples/jackhammer_record.wav")


audio, sr = librosa.load("/home/user/Documents/bfsr/phase_1/Kamble BFSR Audios/08-10-2021_checked/BFSR 6_checked/ZOOM0035.WAV", sr=None)

start = time.time()
prob, pred_id = infer(classifier=cnn,
                      data=audio,
                      input_sr=sr,
                      desired_sr=desired_sr,
                      max_audio_duration_ms=max_audio_duration_ms,
                      normalize=Normalize(mean=[68.09342314549046], std=[18.991857372854792]),
                      device=device)
end = time.time()
print(f"{idx_to_class[pred_id]}: {prob}, Time: {end - start}")
