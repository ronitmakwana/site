from distutils.log import warn
import time
import torch
from model import AudioCNNClassifier
from dataset_utils import get_datasets
from torch.utils.data import DataLoader
from torch import nn, optim
import warnings


warnings.filterwarnings('ignore')


''' to detect what causes nan loss
 only for debugging purposes
 slows down training
'''
# torch.autograd.set_detect_anomaly(True)

desired_sr = 16000
max_audio_duration_ms = 5000
nb_epochs = 1000
batch_size = 8
device = 'cuda:1' if torch.cuda.is_available() else 'cpu'

train_dataset, val_dataset, _ = get_datasets(meta_path="/home/user/Documents/bfsr/phase_2/annotations.csv",
                                    data_dir_path="/home/user/Documents/bfsr/phase_2",
                                    desired_sr=desired_sr,
                                    max_audio_duration_ms=max_audio_duration_ms)

train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, pin_memory=True, num_workers=40)
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=True, pin_memory=True, num_workers=40)

model = AudioCNNClassifier().to(device)

criterion = nn.CrossEntropyLoss(weight=torch.tensor(train_dataset.class_weights, dtype=torch.float32)).to(device)
optimizer = optim.Adam(params=model.parameters(), lr=0.001)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, factor=(1/5), patience=10)

min_val_loss = 100

for i in range(nb_epochs):
    train_loss = 0
    val_loss = 0
    start = time.time()

    model.train()
    for data, labels in train_loader:
        # print(data.shape)
        data = data.to(device)
        labels = labels.to(device)
        optimizer.zero_grad()

        outputs = model(data)
        loss = criterion(outputs, labels)

        loss.backward()
        optimizer.step()

        train_loss += (loss.item() * data.size(0))

    model.eval()
    with torch.no_grad():
        for data, labels in val_loader:
            data = data.to(device)
            labels = labels.to(device)

            outputs = model(data)
            loss = criterion(outputs, labels)

            val_loss += (loss.item() * data.size(0))

    train_loss /= len(train_dataset)
    val_loss /= len(val_dataset)

    if val_loss < min_val_loss:
        min_val_loss = val_loss
        torch.save({
            'epoch': i + 1,
            'val_loss': val_loss,
            'optimizer_state_dict': optimizer.state_dict(),
            'model_state_dict': model.state_dict(),
            'scheduler_state_dict': scheduler.state_dict(),
            'idx_to_class': train_dataset.idx_to_class,
            'mean': train_dataset.mean,
            'std': train_dataset.std,
        }, "models/bfsr_cnn_librosa_chiloda_v3.pt")

    print(f"Epoch {i + 1}\t"
          f"Train loss: {train_loss}\t"
          f"Val. loss: {val_loss}\t"
          f"Time: {time.time() - start}s")
    scheduler.step(val_loss)
