from django.shortcuts import redirect, render
from .models import mrdata
from .forms import formdata
# Create your views here.
from pyproj import Proj

# x,y=250006.95,2552484.75


def index(request):
    if request.method == "POST":
        form = formdata(request.POST)
        if form.is_valid():
            a = form.cleaned_data['east']
            b = form.cleaned_data['north']
            c = form.cleaned_data['range']
            d = form.cleaned_data['azimuth']
            e = form.cleaned_data['target']
            print(a,'--------------',b)
            p2 = Proj(init="epsg:32643", proj="utm", zone=43)
            lon, lat = p2(int(a),int(b),inverse=True)
            print(lon,lat)
            print(a,b,c,d,e)
          
            try:
                p = mrdata(east=lon,north=lat,range=c,azimuth=d,target=e)
                # form.save()
                p.save()
            except:
                pass
    form = formdata()
    return render(request,'index.html',{'form':form})


# math = Subject(subject_id=1, name='Math', max_marks=50)  # Case of update
# math.save()


def show(request):
    form = mrdata.objects.all()
    return render(request,'show.html',{'form':form})

def destroy(request,id):
    form = mrdata.objects.get(id=id)
    form.delete()
    return redirect('/show')