from django.contrib import admin
from .models import mrdata

class addata(admin.ModelAdmin):
    list_display = ['east','north','range','azimuth','target','zone']

# Register your models here.

admin.site.register(mrdata,addata)