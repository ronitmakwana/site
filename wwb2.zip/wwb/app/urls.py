from django.urls import path
from .views import index,show,destroy,display



urlpatterns = [
    path('index/',index,name='index'),
    path('show/',show,name='show'),
    path('delete/<int:id>',destroy),
    path('display',display,name='display')
]
