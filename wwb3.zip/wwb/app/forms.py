from django import forms
from .models import mrdata


class formdata(forms.ModelForm):
    class Meta:
        fields = '__all__'
        model = mrdata


