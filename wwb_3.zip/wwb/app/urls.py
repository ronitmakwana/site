from django.urls import path
from .views import index,show,destroy,display,get_data,fetch_data



urlpatterns = [
    path('index/',index,name='index'),
    path('show/',show,name='show'),
    path('delete/<int:id>',destroy),
    path('display',display,name='display'),
    path('shows',fetch_data,name='shows'),
    path('showss',get_data,name='showss')
    

]
