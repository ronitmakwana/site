import json
import re
from django.shortcuts import redirect, render
from .models import mrdata
from .forms import formdata
# Create your views here.
from pyproj import Proj
from pyproj import Transformer
import os
from django.contrib import messages

# arr = {'east': 2479709, 'north': 578934, 'range': 3, 'azimuth': 3, 'target': 3}
# runfile = '/home/ronit/cv_qthread.py'
# def run_file(request):
#     with open(runfile,"r") as rnf:
#         exec(rnf.read())
#     return render(request,'display.html')

def fetch_data(request):
    arr = 0
    file = '/home/ronit/webapp/wwb2/data.json'
    if os.stat(file).st_size==0:
        try:
            print('file is empty','------------------')
            messages.error(request,'File is empty cannot find data  ')
        except:
            pass 
    else:
        try:
            with open(file,'r') as f:
                data = f.read()
                arr = json.loads(data)
                print(arr)
                messages.success(request,'Data fetched successfully')
                # print(q['east'])
            form = formdata(request.GET)
            if form.is_valid():
                a = form.cleaned_data['east']
                b = form.cleaned_data['north']
                c = form.cleaned_data['range']
                d = form.cleaned_data['azimuth']
                e = form.cleaned_data['target']
        except:
            pass
    form = formdata()
    return render(request,'index.html',{'arr':arr})

def get_data(request):

    if request.method == "POST":
        form = formdata(request.POST)
        if form.is_valid():
            a = form.cleaned_data['east']
            b = form.cleaned_data['north']
            c = form.cleaned_data['range']
            d = form.cleaned_data['azimuth']
            e = form.cleaned_data['target']
       
            print(a,'--------------',b)

            transfrom = Transformer.from_crs(24379, 4326)
            point_43279 = [(float(a), float(b))]
            point_4326 = transfrom.itransform(point_43279)
            my_string = str(*point_4326)
            coord = "POINT " + my_string.replace(',', '')
            coord_str = my_string[1:-1]
            lon, lat = float(coord_str.split(',')[0]), float(coord_str.split(',')[1])
            # p_geom = Point((72.715595, 23.234998))
            print(lon,lat)

            try:
                p = mrdata(east=lat,north=lon,range=c,azimuth=d,target=e)
                # form.save()
                p.save()
                # return redirect('/')
                messages.success(request,'Data has been saved in database')
            except:
                pass
    form = formdata()
    form = mrdata.objects.last()
    return render(request,'index.html',{'form':form})

   
def index(request):
    return render(request,'index.html')


# math = Subject(subject_id=1, name='Math', max_marks=50)  # Case of update
# math.save()


def show(request):
    form = mrdata.objects.all()
    return render(request,'show.html',{'form':form})

def destroy(request,id):
    form = mrdata.objects.get(id=id)
    form.delete()
    return redirect('/display')


def display(request):
    form = mrdata.objects.all()
    return render(request,'display.html',{'form':form})


    #23.1863681,72.6882107
    #22.9914688,71.4555222